# Literature used in pathway prioritisation

These sources justify the proposed biological mechanisms. They do not
experimentally validate the individual orthogroups.

- Barott, K.L., Venn, A.A., Perez, S.O., Tambutté, S. and Tresguerres, M.
  (2015). Coral host cells acidify symbiotic algal microenvironment to promote
  photosynthesis. *PNAS*, 112, 607–612.
  https://doi.org/10.1073/pnas.1413483112
- Davy, S.K., Allemand, D. and Weis, V.M. (2012). Cell biology of
  cnidarian–dinoflagellate symbiosis. *Microbiology and Molecular Biology
  Reviews*, 76, 229–261. https://doi.org/10.1128/MMBR.05014-11
- Doering, T. et al. (2023). Comparing the role of ROS and RNS in the thermal
  stress response of two cnidarian models, *Exaiptasia diaphana* and *Galaxea
  fascicularis*. *Antioxidants*, 12, 1057.
  https://doi.org/10.3390/antiox12051057
- Palmer, C.V. and Traylor-Knowles, N. (2012). Towards an integrated network of
  coral immune mechanisms. *Proceedings of the Royal Society B*, 279,
  4106–4114. https://doi.org/10.1098/rspb.2012.1477
- Roth, M.S. (2014). The engine of the reef: photobiology of the coral–algal
  symbiosis. *Frontiers in Microbiology*, 5, 422.
  https://doi.org/10.3389/fmicb.2014.00422
- Tame, A. et al. (2023). mTORC1 regulates phagosome digestion of symbiotic
  bacteria for intracellular nutritional symbiosis in a deep-sea mussel.
  *Science Advances*, 9, eadg8364.
  https://doi.org/10.1126/sciadv.adg8364
- Weis, V.M. (2019). Cell biology of coral symbiosis: foundational study can
  inform solutions to the coral reef crisis. *Integrative and Comparative
  Biology*, 59, 845–855. https://doi.org/10.1093/icb/icz067

Additional sources used by individual screening rules are emitted by Stage 23
as `literature_sources.tsv`. Tame et al. (2023) concerns mussel–bacterial
symbiosis and is therefore comparative mechanistic evidence rather than direct
cnidarian evidence. Barott et al. (2015), Davy et al. (2012) and Tame et al.
(2023) support symbiosome/phagosome or lysosomal mechanisms generally; they do
not establish a CLN3-specific role in cnidarian symbiosis.

