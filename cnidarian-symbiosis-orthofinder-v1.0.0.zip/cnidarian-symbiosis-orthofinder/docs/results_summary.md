# Results snapshot

## Orthogroup inference

- Species: 15
- Proteins: 442,747
- Assigned to orthogroups: 421,353 (95.2%)
- Unassigned: 21,394 (4.8%)
- Orthogroups: 32,438
- Species-specific orthogroups: 7,738

Assignment was lowest in *Mastigias papua* (90.0%) and highest in
*Pocillopora damicornis* (98.8%). *Hydra vulgaris* and *Leptogorgia
sarmentosa* had conspicuously high proportions of genes in species-specific
orthogroups (21.8% and 18.9%, respectively).

## Candidate distribution and HMM validation

- Candidate union: 2,864 orthogroups
- Single-species candidates: 1,496
- Replicated candidates: 1,368
- Cross-lineage candidates: 250
- Broad candidates: 32
- Universal candidates: 0
- HMM-strict candidates: 1,036 (36.2%)
- Candidates with non-symbiotic HMM hits: 1,828

The host-group-specific sets contained 971 coral, 871 anemone, 595 jellyfish
and 177 hydra candidates. HMM-strict retention was highest among anemone-
specific (43.9%) and coral-specific candidates (41.8%) and lowest among
hydra-specific candidates (18.1%).

## Functional annotation

InterProScan analysed 19,582 sequences. At least one database match was
obtained for 17,985 sequences (91.8%), whereas 1,597 lacked a match. The output
contained 250,190 raw matches, 136,874 member-database signature records,
60,123 InterPro assignments, 53,996 GO assignments and 32,058 pathway
assignments. Assignment totals are annotation records, not unique proteins.

## Functional enrichment

FDR-significant results included 3 GO, 27 InterPro, 16 PANTHER and 15 Pfam
terms in the cross-lineage set; and 1 GO, 20 InterPro, 7 PANTHER and 11 Pfam
terms in the replicated set. Two GO terms were significant among HMM-strict
replicated candidates. Complete term-level results are provided in Table S3.

## Final pathway candidates

Literature-guided screening prioritised 33 orthogroups before KEGG
cross-validation. BlastKOALA assigned KOs to 184 of the original 2,864
representatives. Final manual curation retained 12 orthogroups containing 36
protein members across 23 orthogroup–species occurrences.

Primary candidates:

- OG0021949, glutathione peroxidase-like;
- OG0016019, glutathione synthase-like;
- OG0025219, TRAF5-like;
- OG0023351, V-type proton ATPase subunit-like.

Secondary candidates comprise BMPR1A-like, Rab5A-like, Rab10-like,
gelsolin/villin-like and four CLN3-like orthogroups.

