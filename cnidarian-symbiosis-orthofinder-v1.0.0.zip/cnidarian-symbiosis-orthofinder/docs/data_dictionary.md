# Data dictionary

## `data/orthofinder`

- `Statistics_Overall.tsv`: global counts and percentages from OrthoFinder.
- `Statistics_PerSpecies.tsv`: transposed species-level assignment and
  species-specific orthogroup statistics.
- `Orthogroups.GeneCount.tsv`: copy-number matrix by orthogroup and species.
- `Orthogroups_SpeciesOverlaps.tsv`: pairwise number of shared orthogroups.
- `Orthogroups_UnassignedGenes.tsv`: identifiers not assigned to orthogroups.
- `SpeciesTree_rooted.txt`: rooted Newick tree inferred by OrthoFinder.

## `data/candidates`

- `candidate_master.tsv`: one row per candidate orthogroup, with candidate-set
  flags and species copy counts.
- `candidate_membership.long.tsv`: long-format species and protein membership.
- `filter_summary.tsv`: candidate-set totals.
- `absence_validation.tsv`: HMM hit count, non-symbiotic species hit count and
  final absence status for each candidate.

## `data/annotation` and `data/enrichment`

- `candidate_annotations.tsv`: representative-level functional annotation.
- `interproscan_run_summary.tsv`: aggregate annotation coverage.
- `functional_enrichment.tsv`: combined term-level enrichment results.
- database-specific enrichment tables: GO, InterPro, PANTHER, Pfam and pathway
  views of the combined output.
- `enrichment_set_summary.tsv`: selected, comparator and universe sizes.

## `data/final_candidates`

- `Figure_5_candidate_evidence_data.tsv`: report tier, species copy numbers,
  support sources, evidence class and proposed mechanism for all 12 candidates.
- `final_candidate_summary.tsv`: joined report table, curation rationale and
  evidence matrix generated from the workbook and manifest.
- `Pathway_Candidate_Final_Tables.xlsx`: report-facing primary and secondary
  candidate tables.

## Supplementary tables

- Table S2 contains all 2,864 candidates, their distributions, categories and
  HMM-validation status.
- Table S3 contains the complete functional-enrichment output.

