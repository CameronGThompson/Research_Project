# GitHub release checklist

Before publishing this package:

1. Replace the repository URL placeholder in `README.md`.
2. Add the study author, supervisors and institutional acknowledgement.
3. Select an appropriate licence with the institution or supervisor.
4. Confirm that all source proteomes permit redistribution. They are not
   included in this compact package.
5. Check whether KEGG-derived mapping files or images may be redistributed;
   this package contains only project-generated summary results.
6. Run `make all` and confirm that validation passes.
7. Create the repository and push the contents:

   ```bash
   git init
   git add .
   git commit -m "Initial reproducible analysis package"
   git branch -M main
   git remote add origin <repository-url>
   git push -u origin main
   ```

8. Create a tagged release and attach the repository archive if a static
   version is required for the report.

