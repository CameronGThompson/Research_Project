# Workflow

## Scope

This repository begins with the completed OrthoFinder output and follows the
evidence chain used to prioritise symbiosis-associated orthogroups. Genome and
proteome assembly, BUSCO assessment, isoform selection and CD-HIT filtering are
upstream of the package and are not rerun here.

## 1. OrthoFinder comparative structure

Required OrthoFinder files:

- `Comparative_Genomics_Statistics/Statistics_Overall.tsv`
- `Comparative_Genomics_Statistics/Statistics_PerSpecies.tsv`
- `Orthogroups/Orthogroups.GeneCount.tsv`
- `Orthogroups/Orthogroups_UnassignedGenes.tsv`
- `Phylogenetic_Hierarchical_Orthogroups/` or the equivalent species-tree output
- `Species_Tree/SpeciesTree_rooted.txt`
- `Comparative_Genomics_Statistics/Orthogroups_SpeciesOverlaps.tsv`

The package uses these to report global assignment, species-specific
assignment, phylogenetic structure, pairwise orthogroup sharing and
species-specific orthogroups.

## 2. Candidate classification

Orthogroups present in one or more designated symbiotic proteomes and absent
from all seven non-symbiotic proteomes formed the 2,864-member candidate union.
The curation tables distinguish:

- `replicated`: present in at least two symbiotic species;
- `cross-lineage`: present in more than one host group;
- `broad`: present in at least four symbiotic species across multiple groups;
- `universal`: present in all eight symbiotic species;
- host-group-specific and within-group core candidate sets.

The complete classification and species copy numbers are retained in
`data/candidates/candidate_master.tsv`.

## 3. Profile-HMM absence validation

Candidate alignments and profile-HMM searches were used to test apparent
absence from non-symbiotic proteomes. `NO_HMM_HIT_AT_THRESHOLDS` is the strict
retained state; `FLAG_HOMOLOG_DETECTED` records a detectable non-symbiotic
homologue. The summary file is included, while the 38 MB hit-level table and
HMM/alignment intermediates are excluded from the compact GitHub snapshot.

## 4. Functional annotation and enrichment

Representative candidate sequences and a comparator background were annotated
with InterProScan. Enrichment tables contain the selected and comparator
counts, fractions, Haldane-corrected odds ratio, raw P value and Benjamini–
Hochberg FDR. Figure 4 uses a deliberately compact, predefined selection of
informative FDR-significant terms; the complete results are in Table S3.

## 5. Literature-guided pathway screening (Stage 23)

`scripts/23_build_symbiosis_pathway_candidates.sh` and
`scripts/build_symbiosis_pathway_candidates.py` apply the rules in
`config/symbiosis_process_rules.tsv` to completed candidate InterProScan
outputs. Core GO or resolved pathway evidence is required for acceptance;
domain-only matches are retained for review. MetaCyc is optional and was not
used in the final reported evidence chain because the licensed mapping file was
unavailable.

## 6. KEGG cross-validation (Stage 24)

BlastKOALA KO assignments are joined to KEGG pathway and module mappings by
`scripts/build_kegg_symbiosis_validation.py`.

- `KEGG_STRONG`: theme-concordant KEGG evidence plus independent InterPro support;
- `KEGG_SUPPORTED`: theme-concordant KEGG evidence without InterPro support;
- `KEGG_DISCORDANT`: relevant but theme-discordant KEGG evidence;
- `NO_RELEVANT_KEGG`: assigned KO without a relevant predefined pathway/module;
- `NO_KO`: no BlastKOALA assignment;
- `KEGG_REVIEW`: KEGG-only lead outside the Stage 23 accepted set.

## 7. Final report curation (Stage 25)

The transparent manifest `config/final_report_candidate_curation.tsv` records
the order, reporting tier, biological rationale, interpretive caveat and
literature keys for every retained orthogroup. Four primary and eight secondary
candidates were retained. The tiers are reporting priorities, not statistical
confidence intervals or experimental validation categories.

## HPC execution

The SLURM templates in `hpc/slurm/` preserve the BluePebble execution pattern.
They should be reviewed before reuse because account, partition, memory and
wall-time settings are cluster-specific.

