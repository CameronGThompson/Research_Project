#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
OUTPUT_DIR="${PROJECT_ROOT}/results/symbiosis_pathway_candidates/final_report"
CHECKPOINT="${PROJECT_ROOT}/.checkpoints/25_build_final_report_candidates.done"

if [[ "${FORCE:-0}" != "1" && -s "${CHECKPOINT}" && \
      -s "${OUTPUT_DIR}/final_candidate_orthogroups.tsv" && \
      -s "${OUTPUT_DIR}/final_candidate_proteins.faa" && \
      -s "${OUTPUT_DIR}/run_summary.tsv" ]]; then
    echo "Stage 25 already complete. Set FORCE=1 to rebuild."
    exit 0
fi

mkdir -p "${OUTPUT_DIR}" "$(dirname "${CHECKPOINT}")"

command=(
    python3 "${PROJECT_ROOT}/scripts/build_final_report_candidates.py"
    --project-root "${PROJECT_ROOT}"
    --curation "${PROJECT_ROOT}/config/final_report_candidate_curation.tsv"
    --output-dir "${OUTPUT_DIR}"
)

if [[ -n "${PROTEOME_DIR:-}" ]]; then
    command+=(--proteome-dir "${PROTEOME_DIR}")
fi

"${command[@]}"
date -Iseconds > "${CHECKPOINT}"

