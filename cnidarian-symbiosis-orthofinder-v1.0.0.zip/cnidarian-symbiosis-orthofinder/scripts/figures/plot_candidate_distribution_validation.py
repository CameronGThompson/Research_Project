#!/usr/bin/env python3
"""Create the two-panel candidate distribution and HMM-validation figure."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpecFromSubplotSpec


SET_NAMES = [
    "Coral",
    "Anemone",
    "Jellyfish",
    "Hydra",
    "Replicated",
    "Cross-lineage",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot candidate-set intersections and HMM-validation totals."
    )
    parser.add_argument("--candidate-master", required=True, type=Path)
    parser.add_argument("--absence-validation", required=True, type=Path)
    parser.add_argument("--output-prefix", required=True, type=Path)
    parser.add_argument("--dpi", default=300, type=int)
    return parser.parse_args()


def load_data(
    candidate_path: Path, validation_path: Path
) -> tuple[pd.DataFrame, pd.Series, dict[str, int]]:
    candidates = pd.read_csv(candidate_path, sep="\t")
    validation = pd.read_csv(validation_path, sep="\t")

    required_candidate = {
        "orthogroup",
        "symbiotic_groups_present",
        "tier__symbiotic_only_replicated",
        "tier__symbiotic_only_cross_lineage",
    }
    required_validation = {"orthogroup", "absence_status"}
    if not required_candidate.issubset(candidates.columns):
        missing = sorted(required_candidate - set(candidates.columns))
        raise ValueError("Candidate table is missing: " + ", ".join(missing))
    if not required_validation.issubset(validation.columns):
        missing = sorted(required_validation - set(validation.columns))
        raise ValueError("Validation table is missing: " + ", ".join(missing))
    if candidates["orthogroup"].duplicated().any():
        raise ValueError("Candidate table contains duplicate orthogroup identifiers.")
    if validation["orthogroup"].duplicated().any():
        raise ValueError("Validation table contains duplicate orthogroup identifiers.")
    if set(candidates["orthogroup"]) != set(validation["orthogroup"]):
        raise ValueError("Candidate and validation tables contain different orthogroups.")

    group_flags = candidates["symbiotic_groups_present"].fillna("").str.get_dummies(",")
    flags = pd.DataFrame(
        {
            "Coral": group_flags.get("coral", pd.Series(False, index=candidates.index)).astype(bool),
            "Anemone": group_flags.get("anemone", pd.Series(False, index=candidates.index)).astype(bool),
            "Jellyfish": group_flags.get("jellyfish", pd.Series(False, index=candidates.index)).astype(bool),
            "Hydra": group_flags.get("hydra", pd.Series(False, index=candidates.index)).astype(bool),
            "Replicated": candidates["tier__symbiotic_only_replicated"].astype(bool),
            "Cross-lineage": candidates["tier__symbiotic_only_cross_lineage"].astype(bool),
        }
    )

    intersections = flags.value_counts(sort=True)
    intersections.index = intersections.index.set_names(SET_NAMES)
    set_sizes = flags.sum(axis=0).astype(int)

    merged = candidates[["orthogroup"]].merge(
        validation[["orthogroup", "absence_status"]],
        on="orthogroup",
        validate="one_to_one",
    )
    strict = int((merged["absence_status"] == "NO_HMM_HIT_AT_THRESHOLDS").sum())
    totals = {
        "All candidates": len(candidates),
        "Replicated": int(flags["Replicated"].sum()),
        "HMM-strict": strict,
    }

    expected = {"All candidates": 2864, "Replicated": 1368, "HMM-strict": 1036}
    if totals != expected:
        raise ValueError(f"Unexpected summary totals: {totals}; expected {expected}.")
    return flags, intersections, totals


def draw_upset(
    fig: plt.Figure,
    subplot_spec,
    flags: pd.DataFrame,
    intersections: pd.Series,
) -> None:
    layout = GridSpecFromSubplotSpec(
        2,
        2,
        subplot_spec=subplot_spec,
        width_ratios=[1.25, 4.4],
        height_ratios=[2.5, 1.65],
        wspace=0.04,
        hspace=0.04,
    )
    ax_blank = fig.add_subplot(layout[0, 0])
    ax_bars = fig.add_subplot(layout[0, 1])
    ax_sets = fig.add_subplot(layout[1, 0])
    ax_matrix = fig.add_subplot(layout[1, 1])
    ax_blank.axis("off")

    navy = "#1F4E79"
    active = "#253746"
    inactive = "#D4D8DC"
    grid_colour = "#E5E7E9"

    combination_rows = [tuple(bool(value) for value in index) for index in intersections.index]
    values = intersections.to_numpy(dtype=int)
    x = np.arange(len(values))

    ax_bars.bar(x, values, width=0.72, color=navy, edgecolor="white", linewidth=0.5)
    for position, value in zip(x, values):
        ax_bars.text(
            position,
            value + max(values) * 0.018,
            f"{value:,}",
            ha="center",
            va="bottom",
            fontsize=7.3,
            rotation=90 if value < 10 else 0,
            color="#2E3235",
        )
    ax_bars.set_ylabel("Orthogroups")
    ax_bars.set_title("Candidate-set intersections", loc="left", fontsize=12, fontweight="bold", pad=8)
    ax_bars.set_xticks([])
    ax_bars.set_xlim(-0.6, len(values) - 0.4)
    ax_bars.set_ylim(0, max(values) * 1.16)
    ax_bars.grid(axis="y", color=grid_colour, linewidth=0.7)
    ax_bars.set_axisbelow(True)
    for spine in ("top", "right", "bottom"):
        ax_bars.spines[spine].set_visible(False)
    ax_bars.spines["left"].set_color("#92979B")

    set_sizes = flags[SET_NAMES].sum(axis=0).astype(int)
    y = np.arange(len(SET_NAMES))
    ax_sets.barh(y, set_sizes.to_numpy(), color="#5D7892", height=0.62)
    ax_sets.invert_xaxis()
    ax_sets.set_yticks(y, SET_NAMES, fontsize=9)
    ax_sets.tick_params(axis="y", length=0, pad=5)
    ax_sets.set_xlabel("Set size", fontsize=9)
    ax_sets.set_ylim(len(SET_NAMES) - 0.5, -0.5)
    ax_sets.grid(axis="x", color=grid_colour, linewidth=0.6)
    ax_sets.set_axisbelow(True)
    for row, value in zip(y, set_sizes):
        ax_sets.text(
            value * 0.98,
            row,
            f"{value:,}",
            ha="left",
            va="center",
            fontsize=7.5,
            color="white",
            fontweight="bold",
        )
    for spine in ("top", "right", "left"):
        ax_sets.spines[spine].set_visible(False)
    ax_sets.spines["bottom"].set_color("#92979B")

    for row in y:
        ax_matrix.axhline(row, color="#F0F1F2", linewidth=0.8, zorder=0)

    for column, membership in enumerate(combination_rows):
        active_rows = [row for row, included in enumerate(membership) if included]
        if len(active_rows) > 1:
            ax_matrix.plot(
                [column, column],
                [min(active_rows), max(active_rows)],
                color=active,
                linewidth=1.6,
                zorder=2,
            )
        for row, included in enumerate(membership):
            ax_matrix.scatter(
                column,
                row,
                s=31 if included else 18,
                color=active if included else inactive,
                edgecolor="none",
                zorder=3,
            )

    ax_matrix.set_xlim(-0.6, len(values) - 0.4)
    ax_matrix.set_ylim(len(SET_NAMES) - 0.5, -0.5)
    ax_matrix.set_xticks([])
    ax_matrix.set_yticks([])
    for spine in ax_matrix.spines.values():
        spine.set_visible(False)


def draw_validation_bars(fig: plt.Figure, subplot_spec, totals: dict[str, int]) -> None:
    ax = fig.add_subplot(subplot_spec)
    labels = list(totals)
    values = [totals[label] for label in labels]
    colours = ["#1F4E79", "#3A8D7C", "#D97732"]
    x = np.arange(len(labels))

    bars = ax.bar(x, values, width=0.64, color=colours, edgecolor="white", linewidth=0.7)
    overall = totals["All candidates"]
    for bar, value in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            value + 80,
            f"{value:,}\n({100 * value / overall:.1f}%)",
            ha="center",
            va="bottom",
            fontsize=9.5,
            fontweight="bold",
            color="#2E3235",
        )

    ax.set_xticks(x, ["All\ncandidates", "Replicated\ncandidates", "HMM-strict\ncandidates"])
    ax.set_ylabel("Number of orthogroups")
    ax.set_title("Candidate-set totals", loc="left", fontsize=12, fontweight="bold", pad=8)
    ax.set_ylim(0, 3400)
    ax.grid(axis="y", color="#E5E7E9", linewidth=0.7)
    ax.set_axisbelow(True)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    ax.spines["left"].set_color("#92979B")
    ax.spines["bottom"].set_color("#92979B")


def main() -> None:
    args = parse_args()
    flags, intersections, totals = load_data(args.candidate_master, args.absence_validation)

    fig = plt.figure(figsize=(15.5, 8.5), facecolor="white")
    outer = fig.add_gridspec(1, 2, width_ratios=[2.55, 1.0], wspace=0.22)
    draw_upset(fig, outer[0], flags, intersections)
    draw_validation_bars(fig, outer[1], totals)

    fig.suptitle(
        "Distribution and HMM validation of symbiosis-associated orthogroups",
        x=0.055,
        y=0.995,
        ha="left",
        fontsize=16,
        fontweight="bold",
    )
    fig.text(0.015, 0.965, "A", fontsize=15, fontweight="bold")
    fig.text(0.742, 0.965, "B", fontsize=15, fontweight="bold")
    fig.subplots_adjust(left=0.07, right=0.985, bottom=0.09, top=0.91)

    args.output_prefix.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output_prefix.with_suffix(".png"), dpi=args.dpi, facecolor="white")
    fig.savefig(args.output_prefix.with_suffix(".svg"), facecolor="white")
    fig.savefig(args.output_prefix.with_suffix(".pdf"), facecolor="white")
    plt.close(fig)

    print(f"Candidate orthogroups: {totals['All candidates']:,}")
    print(f"Exact intersections plotted: {len(intersections)}")
    for suffix in (".png", ".svg", ".pdf"):
        print(args.output_prefix.with_suffix(suffix))


if __name__ == "__main__":
    main()
