#!/usr/bin/env python3
"""Plot assigned and unassigned proteins from OrthoFinder Statistics_PerSpecies.tsv.

The OrthoFinder file is transposed: statistics are rows and species are columns.
By default this script produces a 100% stacked horizontal bar chart so assignment
rates can be compared independently of proteome size. Use ``--mode count`` to
plot absolute protein counts instead.
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MultipleLocator


TOTAL_ROW = "Number of genes"
ASSIGNED_ROW = "Number of genes in orthogroups"
UNASSIGNED_ROW = "Number of unassigned genes"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create a horizontal stacked bar chart of proteins assigned and "
            "unassigned to orthogroups from Statistics_PerSpecies.tsv."
        )
    )
    parser.add_argument("--input", required=True, type=Path, help="Input TSV file")
    parser.add_argument(
        "--output-prefix",
        required=True,
        type=Path,
        help="Output path without an extension; .png and .svg are written",
    )
    parser.add_argument(
        "--mode",
        choices=("percent", "count"),
        default="percent",
        help="Plot percentages (default) or absolute counts",
    )
    parser.add_argument(
        "--order",
        choices=("assignment", "input", "alphabetical"),
        default="assignment",
        help=(
            "Species order: lowest assigned percentage first (default), "
            "input-file order, or alphabetical"
        ),
    )
    parser.add_argument(
        "--dpi", type=int, default=300, help="PNG resolution (default: 300 dpi)"
    )
    return parser.parse_args()


def read_orthofinder_statistics(path: Path) -> list[dict[str, float | int | str]]:
    """Read and validate the required rows from a transposed OrthoFinder TSV."""
    if not path.is_file():
        raise FileNotFoundError(f"Input file does not exist: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle, delimiter="\t"))

    if not rows or len(rows[0]) < 2:
        raise ValueError("The input does not appear to be a valid per-species TSV.")

    species = [value.strip() for value in rows[0][1:]]
    metrics = {
        row[0].strip(): [value.strip() for value in row[1:]]
        for row in rows[1:]
        if row and row[0].strip()
    }

    missing = [
        name for name in (TOTAL_ROW, ASSIGNED_ROW, UNASSIGNED_ROW) if name not in metrics
    ]
    if missing:
        raise ValueError("Required row(s) missing: " + ", ".join(missing))

    records: list[dict[str, float | int | str]] = []
    for index, raw_name in enumerate(species):
        try:
            total = int(float(metrics[TOTAL_ROW][index]))
            assigned = int(float(metrics[ASSIGNED_ROW][index]))
            unassigned = int(float(metrics[UNASSIGNED_ROW][index]))
        except (IndexError, ValueError) as exc:
            raise ValueError(f"Invalid protein count for species '{raw_name}'.") from exc

        if total <= 0:
            raise ValueError(f"Total protein count must be positive for '{raw_name}'.")
        if assigned < 0 or unassigned < 0:
            raise ValueError(f"Negative protein count found for '{raw_name}'.")
        if assigned + unassigned != total:
            raise ValueError(
                f"Counts do not reconcile for '{raw_name}': assigned ({assigned:,}) + "
                f"unassigned ({unassigned:,}) != total ({total:,})."
            )

        records.append(
            {
                "raw_name": raw_name,
                "label": clean_species_label(raw_name),
                "total": total,
                "assigned": assigned,
                "unassigned": unassigned,
                "assigned_pct": 100.0 * assigned / total,
                "unassigned_pct": 100.0 * unassigned / total,
                "input_index": index,
            }
        )
    return records


def clean_species_label(name: str) -> str:
    """Convert OrthoFinder file-style species names into readable labels."""
    cleaned = re.sub(r"_proteins(?:\.primary)?(?:\.dedup)?$", "", name)
    cleaned = re.sub(r"(?:\.primary)?(?:\.dedup)?$", "", cleaned)
    parts = cleaned.split("_")

    if len(parts) >= 2 and len(parts[0]) == 1:
        label = f"{parts[0]}. " + " ".join(parts[1:])
    else:
        label = " ".join(parts)

    label = re.sub(r"\bsp\b", "sp.", label)
    return label


def sort_records(
    records: list[dict[str, float | int | str]], order: str
) -> list[dict[str, float | int | str]]:
    if order == "assignment":
        # Lowest assignment rate is displayed at the top of the chart.
        return sorted(records, key=lambda item: (-float(item["assigned_pct"]), str(item["label"])))
    if order == "alphabetical":
        # Reverse here because barh displays the final item at the top.
        return sorted(records, key=lambda item: str(item["label"]), reverse=True)
    return records


def plot(records: list[dict[str, float | int | str]], mode: str, output_prefix: Path, dpi: int) -> None:
    labels = [str(item["label"]) for item in records]
    assigned_pct = [float(item["assigned_pct"]) for item in records]
    unassigned_pct = [float(item["unassigned_pct"]) for item in records]

    if mode == "percent":
        assigned_values = assigned_pct
        unassigned_values = unassigned_pct
    else:
        assigned_values = [int(item["assigned"]) for item in records]
        unassigned_values = [int(item["unassigned"]) for item in records]

    figure_height = max(5.8, 0.42 * len(records) + 1.5)
    fig, ax = plt.subplots(figsize=(10.5, figure_height))
    y_positions = range(len(records))
    assigned_colour = "#1F4E79"
    unassigned_colour = "#D97732"

    ax.barh(
        y_positions,
        assigned_values,
        color=assigned_colour,
        edgecolor="white",
        linewidth=0.6,
        label="Assigned to orthogroups",
    )
    ax.barh(
        y_positions,
        unassigned_values,
        left=assigned_values,
        color=unassigned_colour,
        edgecolor="white",
        linewidth=0.6,
        label="Unassigned",
    )

    ax.set_yticks(list(y_positions), labels)
    ax.tick_params(axis="y", length=0, pad=7)
    for tick_label in ax.get_yticklabels():
        tick_label.set_fontstyle("italic")
        tick_label.set_fontweight("bold")

    if mode == "percent":
        ax.set_xlim(0, 100)
        ax.xaxis.set_major_locator(MultipleLocator(10))
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:.0f}%"))
        ax.set_xlabel("Percentage of proteins")
        for y, assigned, unassigned in zip(y_positions, assigned_pct, unassigned_pct):
            ax.text(
                assigned / 2,
                y,
                f"{assigned:.1f}%",
                ha="center",
                va="center",
                color="white",
                fontsize=8.5,
                fontweight="bold",
            )
            if unassigned >= 3.0:
                ax.text(
                    assigned + unassigned / 2,
                    y,
                    f"{unassigned:.1f}%",
                    ha="center",
                    va="center",
                    color="white",
                    fontsize=8,
                    fontweight="bold",
                )
    else:
        ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:,.0f}"))
        ax.set_xlabel("Number of proteins")
        maximum = max(int(item["total"]) for item in records)
        ax.set_xlim(0, maximum * 1.12)
        for y, item in zip(y_positions, records):
            ax.text(
                int(item["total"]) + maximum * 0.012,
                y,
                f"{int(item['total']):,}",
                ha="left",
                va="center",
                color="#333333",
                fontsize=8,
            )

    ax.set_title(
        "Protein assignment to OrthoFinder orthogroups",
        loc="left",
        pad=48,
        fontweight="bold",
    )
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.7, alpha=0.8)
    ax.set_axisbelow(True)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#777777")
    ax.legend(
        loc="lower center",
        bbox_to_anchor=(0.5, 1.005),
        ncol=2,
        frameon=False,
        borderaxespad=0,
    )

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_prefix.with_suffix(".png"), dpi=dpi, bbox_inches="tight", facecolor="white")
    fig.savefig(output_prefix.with_suffix(".svg"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    records = read_orthofinder_statistics(args.input)
    records = sort_records(records, args.order)
    plot(records, args.mode, args.output_prefix, args.dpi)

    lowest = min(records, key=lambda item: float(item["assigned_pct"]))
    highest = max(records, key=lambda item: float(item["assigned_pct"]))
    print(f"Plotted {len(records)} species in {args.mode} mode.")
    print(f"Lowest assignment: {lowest['label']} ({float(lowest['assigned_pct']):.1f}%)")
    print(f"Highest assignment: {highest['label']} ({float(highest['assigned_pct']):.1f}%)")
    print(f"PNG: {args.output_prefix.with_suffix('.png')}")
    print(f"SVG: {args.output_prefix.with_suffix('.svg')}")


if __name__ == "__main__":
    main()
