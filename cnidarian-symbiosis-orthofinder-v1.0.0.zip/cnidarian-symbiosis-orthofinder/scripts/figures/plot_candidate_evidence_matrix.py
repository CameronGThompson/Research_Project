#!/usr/bin/env python3
"""Create Figure 5: final candidate evidence and species-copy matrix."""

from __future__ import annotations

import argparse
import csv
import textwrap
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle


SPECIES = [
    ("Anthopleura_xanthogrammica", "A. xanthogrammica", "Anemone"),
    ("Condylactis_gigantea", "C. gigantea", "Anemone"),
    ("Oculina_patagonica", "O. patagonica", "Coral"),
    ("Pocillopora_damicornis", "P. damicornis", "Coral"),
    ("Stylophora_pistillata", "S. pistillata", "Coral"),
    ("Hydra_viridissima", "H. viridissima", "Hydra"),
    ("Cassiopea_sp", "Cassiopea sp.", "Jellyfish"),
    ("Mastigias_papua", "M. papua", "Jellyfish"),
]

HOST_GROUP_COLORS = {
    "Anemone": "#8E6BBE",
    "Coral": "#C75B7A",
    "Hydra": "#4C956C",
    "Jellyfish": "#E59F3A",
}

# Evidence tiles record mechanism-relevant support used by the literature/KEGG
# screening, rather than the presence of any generic database annotation.
EVIDENCE = {
    "OG0021949": dict(evidence_class="Corroborated", go=1, interpro=1, ko=1, kegg="Strong", literature=1),
    "OG0016019": dict(evidence_class="Corroborated", go=1, interpro=0, ko=1, kegg="Supported", literature=1),
    "OG0025219": dict(evidence_class="Corroborated", go=1, interpro=0, ko=1, kegg="Supported", literature=1),
    "OG0023351": dict(evidence_class="Reconciled", go=1, interpro=1, ko=1, kegg="Reconciled", literature=1),
    "OG0019571": dict(evidence_class="Preliminary", go=0, interpro=0, ko=1, kegg="Review", literature=1),
    "OG0020396": dict(evidence_class="Preliminary", go=0, interpro=0, ko=1, kegg="Review", literature=1),
    "OG0018974": dict(evidence_class="Preliminary", go=0, interpro=0, ko=1, kegg="Review", literature=1),
    "OG0019938": dict(evidence_class="Preliminary", go=0, interpro=0, ko=1, kegg="Review", literature=1),
    "OG0019845": dict(evidence_class="Preliminary", go=1, interpro=0, ko=1, kegg="Complementary", literature=1),
    "OG0021103": dict(evidence_class="Preliminary", go=1, interpro=0, ko=1, kegg="Complementary", literature=1),
    "OG0021314": dict(evidence_class="Preliminary", go=1, interpro=0, ko=1, kegg="Complementary", literature=1),
    "OG0022406": dict(evidence_class="Preliminary", go=1, interpro=0, ko=1, kegg="Complementary", literature=1),
}

SHORT_LABELS = {
    "OG0021949": "Glutathione peroxidase-like",
    "OG0016019": "Glutathione synthase-like",
    "OG0025219": "TRAF5-like",
    "OG0023351": "V-type proton ATPase subunit",
    "OG0019571": "BMPR1A-like receptor",
    "OG0020396": "Rab5A-like GTPase",
    "OG0018974": "Rab10-like GTPase",
    "OG0019938": "Gelsolin/villin-like",
    "OG0019845": "CLN3-like family 1",
    "OG0021103": "CLN3-like family 2",
    "OG0021314": "CLN3-like family 3",
    "OG0022406": "CLN3-like family 4",
}

PROCESS_LABELS = {
    "Redox and stress homeostasis": "Redox and stress\nhomeostasis",
    "Immune tolerance and NF-kappaB signalling": "Immune tolerance and\nNF-κB signalling",
    "Symbiosome acidification and trafficking": "Symbiosome acidification\nand trafficking",
    "Immune tolerance signalling": "Immune tolerance\nsignalling",
    "Recognition, entry and early symbiosome identity": "Recognition, entry and early\nsymbiosome identity",
    "Endocytic membrane trafficking": "Endocytic membrane\ntrafficking",
    "Phagocytic cytoskeletal remodelling": "Phagocytic cytoskeletal\nremodelling",
    "Lysosomal and symbiosome membrane physiology": "Lysosomal and symbiosome\nmembrane physiology",
}

PROCESS_COLORS = {
    "Redox and stress homeostasis": "#D95F59",
    "Immune tolerance and NF-kappaB signalling": "#7B5EA7",
    "Symbiosome acidification and trafficking": "#2A9D8F",
    "Immune tolerance signalling": "#7B5EA7",
    "Recognition, entry and early symbiosome identity": "#4C78A8",
    "Endocytic membrane trafficking": "#72A6C9",
    "Phagocytic cytoskeletal remodelling": "#E39C37",
    "Lysosomal and symbiosome membrane physiology": "#5C8D89",
}

STATUS_COLORS = {
    "Corroborated": "#1B9E77",
    "Reconciled": "#E69F00",
    "Preliminary": "#7A8DA3",
}

KEGG_COLORS = {
    "Strong": "#146B4A",
    "Supported": "#55A868",
    "Reconciled": "#E69F00",
    "Complementary": "#D8B365",
    "Review": "#6C91BF",
}

KEGG_SYMBOLS = {
    "Strong": "S",
    "Supported": "+",
    "Reconciled": "R",
    "Complementary": "C",
    "Review": "P",
}

COPY_COLORS = {0: "#FFFFFF", 1: "#D7EAF5", 2: "#72B6D7", 3: "#1F6E9C"}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--curation", type=Path, required=True)
    parser.add_argument("--membership", type=Path, required=True)
    parser.add_argument("--output-prefix", type=Path, required=True)
    parser.add_argument("--output-data", type=Path, required=True)
    return parser.parse_args()


def read_tsv(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def prepare_data(curation_path: Path, membership_path: Path):
    curation = sorted(read_tsv(curation_path), key=lambda row: int(row["curation_order"]))
    if len(curation) != 12:
        raise ValueError(f"Expected 12 curated candidates, found {len(curation)}")
    ids = {row["orthogroup"] for row in curation}
    if ids != set(EVIDENCE):
        raise ValueError("Curation manifest and documented evidence map contain different orthogroups")

    counts = {orthogroup: {species: 0 for species, _, _ in SPECIES} for orthogroup in ids}
    for row in read_tsv(membership_path):
        orthogroup = row["orthogroup"]
        species = row["species"]
        if orthogroup in counts and species in counts[orthogroup]:
            counts[orthogroup][species] = int(row["copy_count"])

    records = []
    for row in curation:
        orthogroup = row["orthogroup"]
        record = {
            "curation_order": int(row["curation_order"]),
            "orthogroup": orthogroup,
            "report_tier": row["report_tier"].title(),
            "functional_label": SHORT_LABELS[orthogroup],
            "proposed_symbiosis_process": row["primary_symbiosis_process"],
            **EVIDENCE[orthogroup],
            "literature_keys": row["literature_keys"],
        }
        record.update(counts[orthogroup])
        records.append(record)

    total_proteins = sum(record[species] for record in records for species, _, _ in SPECIES)
    occurrences = sum(record[species] > 0 for record in records for species, _, _ in SPECIES)
    if total_proteins != 36 or occurrences != 23:
        raise ValueError(
            f"Species matrix failed final-output checks: {total_proteins} proteins, "
            f"{occurrences} occurrences"
        )
    return records


def write_data(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "curation_order", "orthogroup", "report_tier", "functional_label",
        "evidence_class", *[species for species, _, _ in SPECIES],
        "go", "interpro", "ko", "kegg", "literature",
        "proposed_symbiosis_process", "literature_keys",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def draw_tile(ax, x, y, facecolor, text="", textcolor="white", edgecolor="#B7C0C8", width=0.78):
    ax.add_patch(Rectangle(
        (x - width / 2, y - 0.38), width, 0.76,
        facecolor=facecolor, edgecolor=edgecolor, linewidth=0.75,
    ))
    if text:
        ax.text(x, y, text, ha="center", va="center", fontsize=8.5,
                fontweight="bold", color=textcolor)


def plot(records, output_prefix: Path):
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    fig = plt.figure(figsize=(18.2, 10.2))
    gs = fig.add_gridspec(1, 3, width_ratios=[5.2, 10.6, 4.5], wspace=0.025)
    label_ax = fig.add_subplot(gs[0, 0])
    matrix_ax = fig.add_subplot(gs[0, 1])
    process_ax = fig.add_subplot(gs[0, 2])
    axes = [label_ax, matrix_ax, process_ax]
    for ax in axes:
        ax.set_ylim(11.65, -1.9)
        ax.set_yticks([])
        ax.set_xticks([])
        ax.set_frame_on(False)

    # Left candidate labels and tier grouping.
    label_ax.set_xlim(0, 1)
    label_ax.text(0.12, -1.38, "Candidate orthogroup", fontsize=11, fontweight="bold", va="center")
    for y, row in enumerate(records):
        label_ax.text(0.12, y, row["orthogroup"], fontsize=9.2, fontweight="bold", va="center")
        label_ax.text(0.39, y, row["functional_label"], fontsize=9.2, va="center")
    # Tier strips and labels.
    label_ax.add_patch(Rectangle((0.01, -0.43), 0.035, 3.86, facecolor="#244A73", edgecolor="none"))
    label_ax.add_patch(Rectangle((0.01, 3.57), 0.035, 7.86, facecolor="#8996A5", edgecolor="none"))
    label_ax.text(0.025, 1.5, "PRIMARY", rotation=90, ha="center", va="center",
                  color="white", fontsize=8.3, fontweight="bold")
    label_ax.text(0.025, 7.5, "SECONDARY", rotation=90, ha="center", va="center",
                  color="white", fontsize=8.3, fontweight="bold")

    # Matrix column positions.
    status_x = 0
    species_x = [1.5 + index for index in range(8)]
    evidence_x = {"GO": 10.5, "InterPro": 11.5, "KO": 12.5, "KEGG": 13.5, "Literature": 14.5}
    matrix_ax.set_xlim(-0.65, 15.1)
    matrix_ax.text(status_x, -1.22, "Evidence\nclass", ha="center", va="center", fontweight="bold")
    matrix_ax.text(5.0, -1.66, "Species copy number", ha="center", va="center", fontsize=11, fontweight="bold")
    matrix_ax.text(12.5, -1.66, "Functional support", ha="center", va="center", fontsize=11, fontweight="bold")

    for x, (_, short_name, _) in zip(species_x, SPECIES):
        matrix_ax.text(x, -0.84, short_name, ha="right", va="center", rotation=55,
                       fontstyle="italic", fontweight="bold", fontsize=9)
    for label, x in evidence_x.items():
        matrix_ax.text(x, -0.82, label, ha="center", va="center", rotation=55,
                       fontweight="bold", fontsize=9)

    # Host-group indicator bars above the species labels.
    group_ranges = [(1.5, 2.5, "Anemone"), (3.5, 5.5, "Coral"),
                    (6.5, 6.5, "Hydra"), (7.5, 8.5, "Jellyfish")]
    for start, end, group in group_ranges:
        matrix_ax.plot([start - 0.42, end + 0.42], [-1.39, -1.39],
                       color=HOST_GROUP_COLORS[group], lw=5, solid_capstyle="butt")

    binary_color = "#277C78"
    literature_color = "#6F4E8C"
    for y, row in enumerate(records):
        # Evidence class tile.
        cls = row["evidence_class"]
        cls_text = {"Corroborated": "COR", "Reconciled": "REC", "Preliminary": "PRE"}[cls]
        draw_tile(matrix_ax, status_x, y, STATUS_COLORS[cls], cls_text, width=0.90)

        # Species copy-number tiles.
        for x, (species, _, _) in zip(species_x, SPECIES):
            count = int(row[species])
            text_color = "white" if count >= 2 else "#163447"
            draw_tile(matrix_ax, x, y, COPY_COLORS[count], str(count) if count else "",
                      text_color, width=0.80)

        # Binary support tiles.
        for key, label in [("go", "GO"), ("interpro", "InterPro"), ("ko", "KO")]:
            present = int(row[key])
            draw_tile(matrix_ax, evidence_x[label], y,
                      binary_color if present else "#F5F5F5",
                      "✓" if present else "–",
                      "white" if present else "#A0A0A0")

        kegg = row["kegg"]
        draw_tile(matrix_ax, evidence_x["KEGG"], y, KEGG_COLORS[kegg], KEGG_SYMBOLS[kegg])
        draw_tile(matrix_ax, evidence_x["Literature"], y, literature_color, "✓")

    # Proposed process annotation.
    process_ax.set_xlim(0, 1)
    process_ax.text(0.12, -1.38, "Proposed symbiosis process", fontsize=11,
                    fontweight="bold", va="center")
    for y, row in enumerate(records):
        process = row["proposed_symbiosis_process"]
        process_ax.add_patch(Rectangle((0.02, y - 0.38), 0.045, 0.76,
                                       facecolor=PROCESS_COLORS[process], edgecolor="none"))
        process_ax.text(0.10, y, PROCESS_LABELS.get(process, "\n".join(textwrap.wrap(process, 28))),
                        va="center", fontsize=9.1)

    # Row guides and primary/secondary divider.
    for ax in axes:
        x0, x1 = ax.get_xlim()
        for boundary in [i + 0.5 for i in range(11)]:
            ax.plot([x0, x1], [boundary, boundary], color="#ECEFF1", lw=0.65, zorder=0)
        ax.plot([x0, x1], [3.5, 3.5], color="#4A5560", lw=1.4, zorder=1)

    fig.suptitle("Final candidate distribution and supporting evidence", y=0.987,
                 fontsize=16, fontweight="bold")

    # Legends: evidence class, copy number, and KEGG interpretation.
    class_handles = [Patch(facecolor=STATUS_COLORS[name], label=name) for name in STATUS_COLORS]
    copy_handles = [Patch(facecolor=COPY_COLORS[n], edgecolor="#B7C0C8", label=str(n)) for n in range(4)]
    kegg_handles = [
        Patch(facecolor=KEGG_COLORS[name], label={
            "Strong": "S  Strong", "Supported": "+  Supported",
            "Reconciled": "R  Reconciled", "Complementary": "C  Complementary",
            "Review": "P  Preliminary review",
        }[name])
        for name in ["Strong", "Supported", "Reconciled", "Complementary", "Review"]
    ]
    fig.legend(class_handles, [h.get_label() for h in class_handles], title="Evidence class",
               loc="lower left", bbox_to_anchor=(0.055, 0.008), ncol=3, frameon=False,
               columnspacing=1.2, handlelength=1.3)
    fig.legend(copy_handles, [h.get_label() for h in copy_handles], title="Protein copies",
               loc="lower center", bbox_to_anchor=(0.40, 0.008), ncol=4, frameon=False,
               columnspacing=0.9, handlelength=1.2)
    fig.legend(kegg_handles, [h.get_label() for h in kegg_handles], title="KEGG evidence",
               loc="lower right", bbox_to_anchor=(0.985, 0.008), ncol=5, frameon=False,
               columnspacing=0.9, handlelength=1.2)

    fig.text(0.5, 0.069,
             "Filled GO, InterPro, KO and literature tiles indicate mechanism-relevant support; open tiles indicate no relevant support.",
             ha="center", fontsize=8.8, color="#4D4D4D")
    fig.subplots_adjust(top=0.88, bottom=0.13, left=0.04, right=0.985)

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "svg", "pdf"):
        kwargs = {"dpi": 300} if ext == "png" else {}
        fig.savefig(output_prefix.with_suffix(f".{ext}"), bbox_inches="tight", **kwargs)
    plt.close(fig)


def plot_v2(records, output_prefix: Path):
    """Render a cleaner matrix with labels isolated in a dedicated header band."""
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    fig = plt.figure(figsize=(18.2, 10.3))
    gs = fig.add_gridspec(
        2, 3,
        width_ratios=[5.2, 10.6, 4.5],
        height_ratios=[1.75, 8.25],
        hspace=0.055,
        wspace=0.025,
    )
    label_header = fig.add_subplot(gs[0, 0])
    matrix_header = fig.add_subplot(gs[0, 1])
    process_header = fig.add_subplot(gs[0, 2])
    label_ax = fig.add_subplot(gs[1, 0])
    matrix_ax = fig.add_subplot(gs[1, 1])
    process_ax = fig.add_subplot(gs[1, 2])

    header_axes = [label_header, matrix_header, process_header]
    body_axes = [label_ax, matrix_ax, process_ax]
    for ax in header_axes:
        ax.set_ylim(0, 1)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_frame_on(False)
    for ax in body_axes:
        ax.set_ylim(11.5, -0.5)
        ax.set_yticks([])
        ax.set_xticks([])
        ax.set_frame_on(False)

    # Shared matrix geometry.
    status_x = 0
    species_x = [1.5 + index for index in range(8)]
    evidence_x = {"GO": 10.5, "InterPro": 11.5, "KO": 12.5, "KEGG": 13.5, "Literature": 14.5}
    matrix_xlim = (-0.65, 15.1)
    matrix_header.set_xlim(*matrix_xlim)
    matrix_ax.set_xlim(*matrix_xlim)

    # Isolated header band: no label can overlap a data tile.
    label_header.set_xlim(0, 1)
    process_header.set_xlim(0, 1)
    label_header.text(0.12, 0.34, "Candidate orthogroup", fontsize=11,
                      fontweight="bold", va="center")
    process_header.text(0.12, 0.34, "Proposed symbiosis process", fontsize=11,
                        fontweight="bold", va="center")
    matrix_header.text(status_x, 0.34, "Evidence\nclass", ha="center", va="center",
                       fontsize=9.5, fontweight="bold")
    matrix_header.text(12.5, 0.91, "Functional support", ha="center", va="center",
                       fontsize=11, fontweight="bold")

    for x, (_, short_name, _) in zip(species_x, SPECIES):
        matrix_header.text(x, 0.08, short_name, ha="left", va="bottom", rotation=60,
                           fontstyle="italic", fontweight="bold", fontsize=8.7,
                           rotation_mode="anchor")
    for label, x in evidence_x.items():
        matrix_header.text(x, 0.08, label, ha="left", va="bottom", rotation=55,
                           fontweight="bold", fontsize=8.8, rotation_mode="anchor")

    # Candidate labels and reporting-tier strips.
    label_ax.set_xlim(0, 1)
    for y, row in enumerate(records):
        label_ax.text(0.12, y, row["orthogroup"], fontsize=9.2,
                      fontweight="bold", va="center")
        label_ax.text(0.39, y, row["functional_label"], fontsize=9.2, va="center")
    label_ax.add_patch(Rectangle((0.01, -0.43), 0.035, 3.86,
                                 facecolor="#244A73", edgecolor="none"))
    label_ax.add_patch(Rectangle((0.01, 3.57), 0.035, 7.86,
                                 facecolor="#8996A5", edgecolor="none"))
    label_ax.text(0.025, 1.5, "PRIMARY", rotation=90, ha="center", va="center",
                  color="white", fontsize=8.3, fontweight="bold")
    label_ax.text(0.025, 7.5, "SECONDARY", rotation=90, ha="center", va="center",
                  color="white", fontsize=8.3, fontweight="bold")

    binary_color = "#277C78"
    literature_color = "#6F4E8C"
    for y, row in enumerate(records):
        cls = row["evidence_class"]
        cls_text = {"Corroborated": "COR", "Reconciled": "REC", "Preliminary": "PRE"}[cls]
        draw_tile(matrix_ax, status_x, y, STATUS_COLORS[cls], cls_text, width=0.90)

        for x, (species, _, _) in zip(species_x, SPECIES):
            count = int(row[species])
            text_color = "white" if count >= 2 else "#163447"
            draw_tile(matrix_ax, x, y, COPY_COLORS[count], str(count) if count else "",
                      text_color, width=0.80)

        for key, label in [("go", "GO"), ("interpro", "InterPro"), ("ko", "KO")]:
            present = int(row[key])
            draw_tile(matrix_ax, evidence_x[label], y,
                      binary_color if present else "#F5F5F5",
                      "✓" if present else "–",
                      "white" if present else "#A0A0A0")

        kegg = row["kegg"]
        draw_tile(matrix_ax, evidence_x["KEGG"], y, KEGG_COLORS[kegg], KEGG_SYMBOLS[kegg])
        draw_tile(matrix_ax, evidence_x["Literature"], y, literature_color, "✓")

    # Proposed-process side annotation.
    process_ax.set_xlim(0, 1)
    for y, row in enumerate(records):
        process = row["proposed_symbiosis_process"]
        process_ax.add_patch(Rectangle((0.02, y - 0.38), 0.045, 0.76,
                                       facecolor=PROCESS_COLORS[process], edgecolor="none"))
        process_ax.text(0.10, y,
                        PROCESS_LABELS.get(process, "\n".join(textwrap.wrap(process, 28))),
                        va="center", fontsize=9.1)

    # Row guides and the primary/secondary divider.
    for ax in body_axes:
        x0, x1 = ax.get_xlim()
        for boundary in [i + 0.5 for i in range(11)]:
            ax.plot([x0, x1], [boundary, boundary], color="#ECEFF1", lw=0.65, zorder=0)
        ax.plot([x0, x1], [3.5, 3.5], color="#4A5560", lw=1.4, zorder=1)

    fig.suptitle("Final candidate distribution and supporting evidence", y=0.987,
                 fontsize=16, fontweight="bold")

    class_handles = [Patch(facecolor=STATUS_COLORS[name], label=name) for name in STATUS_COLORS]
    kegg_handles = [
        Patch(facecolor=KEGG_COLORS[name], label={
            "Strong": "S  Strong", "Supported": "+  Supported",
            "Reconciled": "R  Reconciled", "Complementary": "C  Complementary",
            "Review": "P  Preliminary review",
        }[name])
        for name in ["Strong", "Supported", "Reconciled", "Complementary", "Review"]
    ]
    fig.legend(class_handles, [h.get_label() for h in class_handles], title="Evidence class",
               loc="lower left", bbox_to_anchor=(0.06, 0.008), ncol=3, frameon=False,
               columnspacing=1.2, handlelength=1.3)
    fig.legend(kegg_handles, [h.get_label() for h in kegg_handles], title="KEGG evidence",
               loc="lower right", bbox_to_anchor=(0.985, 0.008), ncol=5, frameon=False,
               columnspacing=0.9, handlelength=1.2)

    fig.text(
        0.5, 0.071,
        "Filled GO, InterPro, KO and literature tiles indicate mechanism-relevant support.",
        ha="center", fontsize=8.8, color="#4D4D4D",
    )
    fig.subplots_adjust(top=0.92, bottom=0.135, left=0.04, right=0.985)

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "svg", "pdf"):
        kwargs = {"dpi": 300} if ext == "png" else {}
        fig.savefig(output_prefix.with_suffix(f".{ext}"), bbox_inches="tight", **kwargs)
    plt.close(fig)


def main():
    args = parse_args()
    records = prepare_data(args.curation, args.membership)
    write_data(args.output_data, records)
    plot_v2(records, args.output_prefix)
    print("Candidates:", len(records))
    print("Primary:", sum(row["report_tier"] == "Primary" for row in records))
    print("Secondary:", sum(row["report_tier"] == "Secondary" for row in records))
    print("Protein members:", sum(row[species] for row in records for species, _, _ in SPECIES))
    print("Orthogroup-species occurrences:", sum(row[species] > 0 for row in records for species, _, _ in SPECIES))


if __name__ == "__main__":
    main()
