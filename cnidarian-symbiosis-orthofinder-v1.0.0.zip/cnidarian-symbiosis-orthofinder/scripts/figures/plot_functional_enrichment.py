#!/usr/bin/env python3
"""Create Figure 4 and the complete supplementary enrichment workbook."""

from __future__ import annotations

import argparse
import math
import textwrap
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.lines import Line2D
from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo


# A deliberately compact, non-redundant selection of FDR-significant terms.
# The IDs are embedded here so the selection is fully reproducible.
SELECTED_TERMS = {
    "cross_lineage": [
        "IPR043502",  # DNA/RNA polymerase superfamily
        "IPR001584",  # Integrase, catalytic core
        "IPR036397",  # Ribonuclease H superfamily
        "IPR043128",  # Reverse transcriptase/diguanylate cyclase domain
        "IPR011604",  # PD-(D/E)XK endonuclease-like superfamily
        "PTHR47526",  # ATP-dependent DNA helicase
        "PTHR23080",  # THAP domain protein
        "PTHR10656",  # MAB21-related protein
    ],
    "replicated": [
        "IPR001584",  # Integrase, catalytic core
        "IPR001190",  # SRCR domain
        "IPR043502",  # DNA/RNA polymerase superfamily
        "IPR043128",  # Reverse transcriptase/diguanylate cyclase domain
        "IPR001507",  # Zona pellucida domain
        "PTHR47526",  # ATP-dependent DNA helicase
        "PTHR10981",  # Battenin/CLN3
        "PF24748",     # Galaxin-like repeats
    ],
    "hmm_strict_replicated": [
        "GO:0008200(InterPro)",  # Ion channel inhibitor activity
        "GO:0090729(InterPro)",  # Toxin activity
    ],
}

FACET_LABELS = {
    "cross_lineage": "Cross-lineage candidates",
    "replicated": "Replicated candidates",
    "hmm_strict_replicated": "HMM-strict replicated candidates",
}

GO_NAMES = {
    "GO:0008200(InterPro)": "Ion channel inhibitor activity",
    "GO:0090729(InterPro)": "Toxin activity",
}

DISPLAY_NAMES = {
    "IPR043128": "Reverse transcriptase/diguanylate cyclase domain",
    "PTHR47526": "ATP-dependent DNA helicase",
    "PTHR23080": "THAP domain protein",
    "PTHR10656": "MAB21-related cell-fate protein",
    "PTHR10981": "Battenin (CLN3)",
}

TERM_TYPE_LABELS = {
    "INTERPRO": "InterPro",
    "PANTHER": "PANTHER",
    "PFAM": "Pfam",
    "GO": "GO",
    "PATHWAY": "Pathway",
}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--enrichment", required=True, type=Path)
    parser.add_argument("--set-summary", required=True, type=Path)
    parser.add_argument("--output-prefix", required=True, type=Path)
    parser.add_argument("--selected-tsv", required=True, type=Path)
    parser.add_argument("--supplement-xlsx", required=True, type=Path)
    return parser.parse_args()


def prepare_data(enrichment_path: Path):
    df = pd.read_csv(enrichment_path, sep="\t")
    numeric = [
        "selected_with_term", "selected_total", "comparator_with_term",
        "comparator_total", "selected_fraction", "comparator_fraction",
        "odds_ratio_haldane", "p_value", "fdr_bh",
    ]
    for column in numeric:
        df[column] = pd.to_numeric(df[column], errors="raise")

    df["enrichment_ratio"] = df["selected_fraction"] / df["comparator_fraction"]
    df["minus_log10_fdr"] = -df["fdr_bh"].map(math.log10)
    df["term_description_display"] = df["term_description"].fillna("").astype(str)
    go_mask = df["term_description_display"].eq("") & df["term_id"].isin(GO_NAMES)
    df.loc[go_mask, "term_description_display"] = df.loc[go_mask, "term_id"].map(GO_NAMES)
    display_mask = df["term_id"].isin(DISPLAY_NAMES)
    df.loc[display_mask, "term_description_display"] = df.loc[display_mask, "term_id"].map(DISPLAY_NAMES)
    df["database"] = df["term_type"].map(TERM_TYPE_LABELS).fillna(df["term_type"])

    selected_parts = []
    for candidate_set, ids in SELECTED_TERMS.items():
        part = df[(df["candidate_set"] == candidate_set) & (df["term_id"].isin(ids))].copy()
        found = set(part["term_id"])
        missing = set(ids) - found
        if missing:
            raise ValueError(f"Missing selected terms for {candidate_set}: {sorted(missing)}")
        if len(part) != len(ids):
            raise ValueError(f"Selected term IDs are not unique for {candidate_set}")
        if (part["fdr_bh"] > 0.05).any():
            bad = part.loc[part["fdr_bh"] > 0.05, "term_id"].tolist()
            raise ValueError(f"Selected terms are not FDR-significant: {bad}")
        part["facet"] = FACET_LABELS[candidate_set]
        selected_parts.append(part)
    selected = pd.concat(selected_parts, ignore_index=True)
    selected["figure_label"] = selected.apply(
        lambda row: f"{row['term_description_display']} ({row['database']})", axis=1
    )
    return df, selected


def wrap_label(label: str, width: int = 47) -> str:
    return "\n".join(textwrap.wrap(label, width=width, break_long_words=False))


def plot_figure(selected: pd.DataFrame, output_prefix: Path):
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 11,
        "xtick.labelsize": 9.5,
        "ytick.labelsize": 9.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    facet_order = list(SELECTED_TERMS)
    height_ratios = [len(SELECTED_TERMS[name]) for name in facet_order]
    fig, axes = plt.subplots(
        3, 1, figsize=(11.2, 11.5), sharex=True,
        gridspec_kw={"height_ratios": height_ratios, "hspace": 0.30},
    )
    cmap = mpl.colormaps["viridis"]
    norm = mpl.colors.Normalize(
        vmin=selected["minus_log10_fdr"].min(),
        vmax=selected["minus_log10_fdr"].max(),
    )

    scatter = None
    for ax, candidate_set in zip(axes, facet_order):
        part = selected[selected["candidate_set"] == candidate_set].copy()
        part = part.sort_values(["enrichment_ratio", "fdr_bh"], ascending=[True, False])
        y = range(len(part))
        sizes = 38 + 8.2 * part["selected_with_term"]
        scatter = ax.scatter(
            part["enrichment_ratio"], list(y),
            s=sizes,
            c=part["minus_log10_fdr"], cmap=cmap, norm=norm,
            edgecolor="white", linewidth=0.75, alpha=0.96, zorder=3,
        )
        ax.set_yticks(list(y), [wrap_label(x) for x in part["figure_label"]])
        ax.set_ylim(-0.75, len(part) - 0.25)
        ax.set_xscale("log")
        ax.set_xlim(1, 55)
        ax.set_xticks([1, 2, 5, 10, 20, 50], ["1", "2", "5", "10", "20", "50"])
        ax.axvline(1, color="#737373", lw=0.9, ls="--", zorder=1)
        ax.grid(axis="x", which="major", color="#D9D9D9", lw=0.7, zorder=0)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(axis="y", length=0, pad=8)
        ax.tick_params(axis="x", direction="out", color="#595959")
        ax.set_title(
            FACET_LABELS[candidate_set], loc="left", pad=8, weight="bold", color="white",
            bbox={"facecolor": "#244A73", "edgecolor": "none", "boxstyle": "square,pad=0.45"},
        )

    axes[-1].set_xlabel("Enrichment ratio (candidate fraction / comparator fraction; logarithmic scale)")
    fig.suptitle(
        "Functional enrichment of symbiosis-associated orthogroups",
        x=0.5, y=0.995, fontsize=15, fontweight="bold",
    )

    # Size legend uses the same area transformation as the plotted points.
    legend_counts = [2, 10, 25, 50]
    handles = [
        Line2D([], [], marker="o", linestyle="", markerfacecolor="#7A7A7A",
               markeredgecolor="white", markersize=math.sqrt(38 + 8.2 * n), label=str(n))
        for n in legend_counts
    ]
    fig.legend(
        handles=handles, title="Annotated candidate\northogroups (n)",
        loc="upper center", bbox_to_anchor=(0.5, 0.962), frameon=False,
        ncol=4, columnspacing=0.9, handletextpad=0.4,
    )

    cbar = fig.colorbar(
        scatter, ax=axes, orientation="horizontal", fraction=0.025, pad=0.075, aspect=45,
    )
    cbar.set_label(r"Statistical significance, $-\log_{10}$(FDR-adjusted $P$)")
    cbar.outline.set_visible(False)

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "svg", "pdf"):
        kwargs = {"dpi": 600} if extension == "png" else {}
        fig.savefig(output_prefix.with_suffix(f".{extension}"), bbox_inches="tight", **kwargs)
    plt.close(fig)


def add_table(ws, df: pd.DataFrame, name: str, header_row: int = 1):
    columns = list(df.columns)
    for col_idx, column in enumerate(columns, 1):
        ws.cell(header_row, col_idx, column)
    for row_idx, row in enumerate(df.itertuples(index=False, name=None), header_row + 1):
        for col_idx, value in enumerate(row, 1):
            if pd.isna(value):
                value = ""
            ws.cell(row_idx, col_idx, value)

    navy = "17365D"
    for cell in ws[header_row]:
        cell.fill = PatternFill("solid", fgColor=navy)
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[header_row].height = 34
    ws.freeze_panes = f"A{header_row + 1}"
    ref = f"A{header_row}:{ws.cell(ws.max_row, ws.max_column).coordinate}"
    table = Table(displayName=name, ref=ref)
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False,
        showRowStripes=True, showColumnStripes=False,
    )
    ws.add_table(table)
    ws.auto_filter.ref = ref
    ws.sheet_view.showGridLines = False
    for idx, column in enumerate(columns, 1):
        if column in {"contributing_orthogroups"}:
            width = 60
        elif column in {"term_description", "term_description_display", "figure_label"}:
            width = 42
        elif column in {"candidate_set", "term_id"}:
            width = 25
        else:
            width = min(max(len(column) + 2, 13), 22)
        ws.column_dimensions[ws.cell(header_row, idx).column_letter].width = width


def write_supplement(df: pd.DataFrame, selected: pd.DataFrame, summary_path: Path, output: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Complete enrichment"

    export_columns = [
        "candidate_set", "term_type", "term_id", "term_description",
        "selected_with_term", "selected_total", "comparator_with_term", "comparator_total",
        "selected_fraction", "comparator_fraction", "enrichment_ratio", "odds_ratio_haldane",
        "p_value", "fdr_bh", "contributing_orthogroups",
    ]
    full = df[export_columns].copy()
    add_table(ws, full, "CompleteEnrichment")
    fdr_col = export_columns.index("fdr_bh") + 1
    fdr_letter = ws.cell(1, fdr_col).column_letter
    ws.conditional_formatting.add(
        f"{fdr_letter}2:{fdr_letter}{ws.max_row}",
        CellIsRule(operator="lessThanOrEqual", formula=["0.05"], fill=PatternFill("solid", fgColor="E2F0D9")),
    )

    sig_ws = wb.create_sheet("Significant terms")
    significant = full[full["fdr_bh"] <= 0.05].sort_values(["candidate_set", "fdr_bh"])
    add_table(sig_ws, significant, "SignificantEnrichment")

    fig_ws = wb.create_sheet("Figure 4 terms")
    fig_columns = [
        "facet", "candidate_set", "term_type", "term_id", "term_description_display",
        "selected_with_term", "selected_total", "comparator_with_term", "comparator_total",
        "selected_fraction", "comparator_fraction", "enrichment_ratio", "odds_ratio_haldane",
        "p_value", "fdr_bh", "contributing_orthogroups",
    ]
    add_table(fig_ws, selected[fig_columns].sort_values(["candidate_set", "fdr_bh"]), "Figure4Terms")

    summary_ws = wb.create_sheet("Set summary")
    summary = pd.read_csv(summary_path, sep="\t")
    add_table(summary_ws, summary, "EnrichmentSetSummary")

    notes = wb.create_sheet("Notes")
    notes_data = [
        ("Supplementary table title", "Complete functional-enrichment results for symbiosis-associated candidate orthogroups."),
        ("Significance threshold", "FDR-adjusted P <= 0.05 (Benjamini-Hochberg correction)."),
        ("Enrichment ratio", "Selected fraction divided by comparator fraction."),
        ("Dot size", "Number of selected candidate orthogroups annotated with the term."),
        ("Figure selection", "Up to eight FDR-significant, interpretable and non-redundant terms were selected per facet. All significant and non-significant tests remain in the complete sheet."),
        ("HMM-strict facet", "The HMM-strict replicated subset is shown because it contained two significant GO terms; the HMM-strict all-candidate set contained no FDR-significant terms."),
    ]
    notes.append(["Item", "Description"])
    for item in notes_data:
        notes.append(item)
    notes.column_dimensions["A"].width = 28
    notes.column_dimensions["B"].width = 115
    for cell in notes[1]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
    for row in notes.iter_rows(min_row=2):
        row[1].alignment = Alignment(wrap_text=True, vertical="top")
    notes.freeze_panes = "A2"
    notes.sheet_view.showGridLines = False

    wb.properties.title = "Complete functional-enrichment output"
    wb.properties.subject = "Supplementary enrichment results supporting Figure 4"
    wb.save(output)


def main():
    args = parse_args()
    df, selected = prepare_data(args.enrichment)
    args.selected_tsv.parent.mkdir(parents=True, exist_ok=True)
    selected.to_csv(args.selected_tsv, sep="\t", index=False)
    plot_figure(selected, args.output_prefix)
    write_supplement(df, selected, args.set_summary, args.supplement_xlsx)
    print(f"Plotted {len(selected)} representative significant terms")
    print(f"Complete enrichment tests: {len(df)}")
    print(f"Significant tests (FDR <= 0.05): {(df['fdr_bh'] <= 0.05).sum()}")


if __name__ == "__main__":
    main()
