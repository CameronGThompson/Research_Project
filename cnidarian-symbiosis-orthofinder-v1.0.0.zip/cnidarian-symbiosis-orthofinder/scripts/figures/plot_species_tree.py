#!/usr/bin/env python3
"""Plot an OrthoFinder Newick species tree with class and symbiosis metadata.

Only Python 3 and matplotlib are required. Outputs are written as a 300-dpi
PNG, editable SVG, and publication-quality PDF.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


CLASS_COLOURS = {
    "Anthozoa": "#6A51A3",
    "Hydrozoa": "#1B9E77",
    "Scyphozoa": "#D95F02",
}
SYMBIOTIC_COLOUR = "#2E7D32"
NON_SYMBIOTIC_COLOUR = "#6B7280"


@dataclass
class Node:
    name: str = ""
    length: float = 0.0
    children: list["Node"] = field(default_factory=list)
    parent: "Node | None" = None
    x: float = 0.0
    y: float = 0.0

    @property
    def is_leaf(self) -> bool:
        return not self.children


class NewickParser:
    def __init__(self, text: str):
        self.text = text.strip()
        self.position = 0

    def parse(self) -> Node:
        root = self._subtree()
        self._skip_space()
        if self._peek() == ";":
            self.position += 1
        self._skip_space()
        if self.position != len(self.text):
            raise ValueError(f"Unexpected Newick content at character {self.position}.")
        return root

    def _subtree(self) -> Node:
        self._skip_space()
        if self._peek() == "(":
            self.position += 1
            children = [self._subtree()]
            while True:
                self._skip_space()
                token = self._peek()
                if token == ",":
                    self.position += 1
                    children.append(self._subtree())
                elif token == ")":
                    self.position += 1
                    break
                else:
                    raise ValueError(f"Expected ',' or ')' at character {self.position}.")
            node = Node(name=self._label(), children=children)
            for child in children:
                child.parent = node
        else:
            name = self._label()
            if not name:
                raise ValueError(f"Missing tip name at character {self.position}.")
            node = Node(name=name)

        self._skip_space()
        if self._peek() == ":":
            self.position += 1
            value = self._read_until({",", ")", ";"}).strip()
            try:
                node.length = float(value)
            except ValueError as exc:
                raise ValueError(f"Invalid branch length '{value}'.") from exc
        return node

    def _label(self) -> str:
        self._skip_space()
        return self._read_until({":", ",", ")", ";"}).strip()

    def _read_until(self, delimiters: set[str]) -> str:
        start = self.position
        while self.position < len(self.text) and self.text[self.position] not in delimiters:
            self.position += 1
        return self.text[start:self.position]

    def _skip_space(self) -> None:
        while self.position < len(self.text) and self.text[self.position].isspace():
            self.position += 1

    def _peek(self) -> str:
        return self.text[self.position] if self.position < len(self.text) else ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot a rooted OrthoFinder species tree with class and symbiosis status."
    )
    parser.add_argument("--tree", required=True, type=Path, help="Rooted Newick tree")
    parser.add_argument("--metadata", required=True, type=Path, help="Metadata TSV")
    parser.add_argument(
        "--output-prefix",
        required=True,
        type=Path,
        help="Output path without an extension",
    )
    parser.add_argument("--dpi", type=int, default=300, help="PNG resolution")
    parser.add_argument(
        "--hide-support",
        action="store_true",
        help="Do not display internal-node support values",
    )
    return parser.parse_args()


def load_metadata(path: Path) -> dict[str, dict[str, str]]:
    required = {"species_id", "display_name", "class", "symbiosis"}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            raise ValueError("Metadata must contain: " + ", ".join(sorted(required)))
        records = {row["species_id"].strip(): row for row in reader}

    for species_id, row in records.items():
        if row["class"] not in CLASS_COLOURS:
            raise ValueError(f"Unsupported class for {species_id}: {row['class']}")
        if row["symbiosis"] not in {"Symbiotic", "Non-symbiotic"}:
            raise ValueError(f"Unsupported symbiosis status for {species_id}: {row['symbiosis']}")
    return records


def leaves(node: Node) -> list[Node]:
    if node.is_leaf:
        return [node]
    result: list[Node] = []
    for child in node.children:
        result.extend(leaves(child))
    return result


def internal_nodes(node: Node) -> list[Node]:
    result = [] if node.is_leaf else [node]
    for child in node.children:
        result.extend(internal_nodes(child))
    return result


def assign_coordinates(root: Node) -> None:
    ordered_leaves = leaves(root)
    for index, leaf in enumerate(ordered_leaves):
        leaf.y = float(index)

    def visit(node: Node, parent_x: float) -> None:
        node.x = parent_x + node.length
        for child in node.children:
            visit(child, node.x)
        if node.children:
            node.y = sum(child.y for child in node.children) / len(node.children)

    # The root branch is not displayed; start it at zero.
    root.length = 0.0
    visit(root, 0.0)


def draw_tree(
    root: Node,
    metadata: dict[str, dict[str, str]],
    output_prefix: Path,
    dpi: int,
    show_support: bool,
) -> None:
    tips = leaves(root)
    tree_ids = {tip.name for tip in tips}
    missing = sorted(tree_ids - set(metadata))
    extra = sorted(set(metadata) - tree_ids)
    if missing or extra:
        message = []
        if missing:
            message.append("missing metadata: " + ", ".join(missing))
        if extra:
            message.append("metadata absent from tree: " + ", ".join(extra))
        raise ValueError("; ".join(message))

    max_depth = max(tip.x for tip in tips)
    label_x = max_depth + max_depth * 0.045
    class_marker_x = max_depth + max_depth * 0.56
    class_text_x = class_marker_x + max_depth * 0.045
    status_marker_x = max_depth + max_depth * 1.02
    status_text_x = status_marker_x + max_depth * 0.045
    right_edge = max_depth + max_depth * 1.52

    fig_height = max(7.0, len(tips) * 0.48 + 1.8)
    fig, ax = plt.subplots(figsize=(13.2, fig_height))

    # Alternating row guides improve alignment across the metadata columns.
    for index in range(len(tips)):
        if index % 2 == 0:
            ax.axhspan(index - 0.45, index + 0.45, color="#F5F6F7", zorder=0)

    for node in internal_nodes(root):
        if node.children:
            child_ys = [child.y for child in node.children]
            ax.plot(
                [node.x, node.x],
                [min(child_ys), max(child_ys)],
                color="#2F3437",
                linewidth=1.15,
                solid_capstyle="butt",
                zorder=2,
            )
            for child in node.children:
                ax.plot(
                    [node.x, child.x],
                    [child.y, child.y],
                    color="#2F3437",
                    linewidth=1.15,
                    solid_capstyle="butt",
                    zorder=2,
                )

        if show_support and node is not root and node.name:
            try:
                support = float(node.name)
                support_text = f"{support:.2f}"
            except ValueError:
                support_text = node.name
            ax.text(
                node.x + max_depth * 0.008,
                node.y - 0.14,
                support_text,
                fontsize=7.2,
                color="#646A70",
                ha="left",
                va="bottom",
                zorder=3,
            )

    # A faint leader aligns variable branch endpoints with fixed tip labels.
    for tip in tips:
        row = metadata[tip.name]
        ax.plot(
            [tip.x, label_x - max_depth * 0.018],
            [tip.y, tip.y],
            color="#C6C9CC",
            linewidth=0.65,
            linestyle=(0, (1.5, 2.2)),
            zorder=1,
        )
        ax.text(
            label_x,
            tip.y,
            row["display_name"],
            fontsize=10.2,
            fontstyle="italic",
            ha="left",
            va="center",
            color="#202326",
        )

        class_colour = CLASS_COLOURS[row["class"]]
        marker_width = max_depth * 0.026
        ax.add_patch(
            Rectangle(
                (class_marker_x - marker_width / 2, tip.y - 0.14),
                marker_width,
                0.28,
                facecolor=class_colour,
                edgecolor="none",
                zorder=4,
            )
        )
        ax.text(
            class_text_x,
            tip.y,
            row["class"],
            fontsize=9.2,
            ha="left",
            va="center",
            color="#303438",
        )

        is_symbiotic = row["symbiosis"] == "Symbiotic"
        ax.scatter(
            [status_marker_x],
            [tip.y],
            s=42,
            marker="o",
            facecolor=SYMBIOTIC_COLOUR if is_symbiotic else "white",
            edgecolor=SYMBIOTIC_COLOUR if is_symbiotic else NON_SYMBIOTIC_COLOUR,
            linewidth=1.2,
            zorder=4,
        )
        ax.text(
            status_text_x,
            tip.y,
            row["symbiosis"],
            fontsize=9.2,
            ha="left",
            va="center",
            color="#303438",
        )

    header_y = -0.92
    ax.text(label_x, header_y, "Species", fontsize=9.2, fontweight="bold", ha="left", va="center")
    ax.text(class_marker_x, header_y, "Class", fontsize=9.2, fontweight="bold", ha="left", va="center")
    ax.text(status_marker_x, header_y, "Symbiosis", fontsize=9.2, fontweight="bold", ha="left", va="center")

    # Scale bar uses a readable value based on the branch-length range.
    scale_length = 0.1
    scale_y = len(tips) - 0.05
    ax.plot([0, scale_length], [scale_y, scale_y], color="#2F3437", linewidth=1.5)
    ax.plot([0, 0], [scale_y - 0.08, scale_y + 0.08], color="#2F3437", linewidth=1.2)
    ax.plot(
        [scale_length, scale_length],
        [scale_y - 0.08, scale_y + 0.08],
        color="#2F3437",
        linewidth=1.2,
    )
    ax.text(
        scale_length / 2,
        scale_y + 0.27,
        "0.1 branch-length units",
        fontsize=8,
        ha="center",
        va="top",
        color="#555B60",
    )

    ax.set_title("Cnidarian species tree", loc="left", fontsize=15, fontweight="bold", pad=15)
    ax.set_xlim(-max_depth * 0.01, right_edge)
    ax.set_ylim(len(tips) + 0.55, -1.25)
    ax.axis("off")

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_prefix.with_suffix(".png"), dpi=dpi, bbox_inches="tight", facecolor="white")
    fig.savefig(output_prefix.with_suffix(".svg"), bbox_inches="tight", facecolor="white")
    fig.savefig(output_prefix.with_suffix(".pdf"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    root = NewickParser(args.tree.read_text(encoding="utf-8")).parse()
    metadata = load_metadata(args.metadata)
    assign_coordinates(root)
    draw_tree(
        root,
        metadata,
        args.output_prefix,
        dpi=args.dpi,
        show_support=not args.hide_support,
    )
    tip_records = [metadata[tip.name] for tip in leaves(root)]
    class_counts = {name: sum(row["class"] == name for row in tip_records) for name in CLASS_COLOURS}
    symbiotic_count = sum(row["symbiosis"] == "Symbiotic" for row in tip_records)
    print(f"Plotted {len(tip_records)} species.")
    print("Classes: " + ", ".join(f"{name}={count}" for name, count in class_counts.items()))
    print(f"Symbiosis: Symbiotic={symbiotic_count}, Non-symbiotic={len(tip_records) - symbiotic_count}")
    for suffix in (".png", ".svg", ".pdf"):
        print(args.output_prefix.with_suffix(suffix))


if __name__ == "__main__":
    main()
