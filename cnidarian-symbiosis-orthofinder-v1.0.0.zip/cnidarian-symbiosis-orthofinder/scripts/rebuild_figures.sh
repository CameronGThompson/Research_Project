#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"

"${PYTHON_BIN}" "${SCRIPT_DIR}/figures/plot_orthogroup_assignment.py" \
    --input "${PROJECT_ROOT}/data/orthofinder/Statistics_PerSpecies.tsv" \
    --output-prefix "${PROJECT_ROOT}/figures/orthofinder/orthogroup_assignment_percent_bold_italic" \
    --mode percent \
    --order assignment

"${PYTHON_BIN}" "${SCRIPT_DIR}/figures/plot_species_tree.py" \
    --tree "${PROJECT_ROOT}/data/orthofinder/SpeciesTree_rooted.txt" \
    --metadata "${PROJECT_ROOT}/config/species_metadata.tsv" \
    --output-prefix "${PROJECT_ROOT}/figures/orthofinder/cnidarian_species_tree_highlighted"

"${PYTHON_BIN}" "${SCRIPT_DIR}/figures/plot_candidate_distribution_validation.py" \
    --candidate-master "${PROJECT_ROOT}/data/candidates/candidate_master.tsv" \
    --absence-validation "${PROJECT_ROOT}/data/candidates/absence_validation.tsv" \
    --output-prefix "${PROJECT_ROOT}/figures/candidates/figure3_candidate_distribution_validation"

"${PYTHON_BIN}" "${SCRIPT_DIR}/figures/plot_functional_enrichment.py" \
    --enrichment "${PROJECT_ROOT}/data/enrichment/functional_enrichment.tsv" \
    --set-summary "${PROJECT_ROOT}/data/enrichment/enrichment_set_summary.tsv" \
    --output-prefix "${PROJECT_ROOT}/figures/enrichment/Figure_4_functional_enrichment_dotplot" \
    --selected-tsv "${PROJECT_ROOT}/figures/enrichment/Figure_4_selected_terms.tsv" \
    --supplement-xlsx "${PROJECT_ROOT}/data/supplementary/Table_S3_complete_functional_enrichment.xlsx"

"${PYTHON_BIN}" "${SCRIPT_DIR}/figures/plot_candidate_evidence_matrix.py" \
    --curation "${PROJECT_ROOT}/config/final_report_candidate_curation.tsv" \
    --membership "${PROJECT_ROOT}/data/candidates/candidate_membership.long.tsv" \
    --output-prefix "${PROJECT_ROOT}/figures/final_candidates/Figure_5_final_candidate_evidence_matrix" \
    --output-data "${PROJECT_ROOT}/data/final_candidates/Figure_5_candidate_evidence_data.tsv"

"${PYTHON_BIN}" "${SCRIPT_DIR}/tables/render_candidate_tables.py" \
    --workbook "${PROJECT_ROOT}/data/final_candidates/Pathway_Candidate_Final_Tables.xlsx" \
    --output-dir "${PROJECT_ROOT}/figures/final_candidates"

"${PYTHON_BIN}" "${SCRIPT_DIR}/tables/build_final_candidate_summary.py"

printf 'Figures and final candidate summary rebuilt successfully.\n'

