#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
RESULT_DIR="${PROJECT_ROOT}/results/symbiosis_pathway_candidates"
RESOURCE_DIR="${PROJECT_ROOT}/resources/symbiosis_pathways"
CHECKPOINT="${PROJECT_ROOT}/.checkpoints/23_build_symbiosis_pathway_candidates.done"

if [[ "${FORCE:-0}" != "1" && -s "${CHECKPOINT}" && \
      -s "${RESULT_DIR}/candidate_orthogroups.tsv" && \
      -s "${RESULT_DIR}/all_pathways_catalog.tsv" ]]; then
    echo "Stage 23 already complete. Set FORCE=1 to rebuild."
    exit 0
fi

mkdir -p "${RESOURCE_DIR}" "${RESULT_DIR}" "$(dirname "${CHECKPOINT}")"

download_reference() {
    local url="$1"
    local destination="$2"
    local temporary="${destination}.part"

    [[ -s "${destination}" ]] && return 0

    if command -v wget >/dev/null 2>&1; then
        wget -q --show-progress "${url}" -O "${temporary}"
    elif command -v curl >/dev/null 2>&1; then
        curl -fL "${url}" -o "${temporary}"
    else
        echo "ERROR: wget or curl is required to download ${url}" >&2
        return 1
    fi

    [[ -s "${temporary}" ]] || {
        echo "ERROR: empty download: ${url}" >&2
        return 1
    }
    mv "${temporary}" "${destination}"
}

download_reference \
    "https://purl.obolibrary.org/obo/go/go-basic.obo" \
    "${RESOURCE_DIR}/go-basic.obo"

download_reference \
    "https://reactome.org/download/current/ReactomePathways.txt" \
    "${RESOURCE_DIR}/ReactomePathways.txt"

command=(
    python3 "${PROJECT_ROOT}/scripts/build_symbiosis_pathway_candidates.py"
    --project-root "${PROJECT_ROOT}"
    --rules "${PROJECT_ROOT}/config/symbiosis_process_rules.tsv"
    --go-obo "${RESOURCE_DIR}/go-basic.obo"
    --reactome-pathways "${RESOURCE_DIR}/ReactomePathways.txt"
    --output-dir "${RESULT_DIR}"
)

if [[ -s "${RESOURCE_DIR}/pathways.dat" ]]; then
    command+=(--metacyc-pathways-dat "${RESOURCE_DIR}/pathways.dat")
else
    echo "NOTE: MetaCyc pathways.dat is absent; MetaCyc accessions will be catalogued without names."
fi

if [[ -n "${PROTEOME_DIR:-}" ]]; then
    command+=(--proteome-dir "${PROTEOME_DIR}")
fi

"${command[@]}"
date -Iseconds > "${CHECKPOINT}"

