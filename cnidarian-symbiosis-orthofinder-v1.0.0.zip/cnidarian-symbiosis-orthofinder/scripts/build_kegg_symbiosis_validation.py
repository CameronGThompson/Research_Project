#!/usr/bin/env python3
"""Cross-check literature-screened orthogroups with BlastKOALA/KEGG.

This is an annotation concordance analysis, not a statistical enrichment test
and not experimental validation.  Stage 23 grades are never changed here.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import re
from collections import defaultdict
from pathlib import Path


KO_RE = re.compile(r"K\d{5}")
PATH_RE = re.compile(r"^(?:path:)?map(\d{5})$")
MODULE_RE = re.compile(r"^(?:md:)?(M\d{5})$")

# KEGG overview/global maps are useful visual summaries but are too broad to
# count as specific mechanistic corroboration in this candidate screen.
GLOBAL_PATHWAY_RANGES = ((1100, 1199), (1200, 1299), (1300, 1399))
EXCLUDED_NAME_RE = re.compile(
    r"(?:\bcancer\b|carcinoma|leukemia|melanoma|viral infection|"
    r"bacterial infection|parasitic infection|pathogenic escherichia|"
    r"drug resistance|addiction|neurodegeneration|alzheimer|parkinson|"
    r"huntington|cardiomyopathy|diabetic complication)",
    flags=re.IGNORECASE,
)


def read_tsv(path: Path):
    with path.open(encoding="utf-8", errors="replace", newline="") as handle:
        lines = (line for line in handle if line.strip() and not line.startswith("#"))
        yield from csv.DictReader(lines, delimiter="\t")


def read_raw_tsv(path: Path):
    with path.open(encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if raw.strip() and not raw.startswith("#"):
                yield raw.rstrip("\n").split("\t")


def write_tsv(path: Path, fields, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            delimiter="\t",
            fieldnames=fields,
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def unique_join(values):
    return ";".join(sorted({str(value) for value in values if str(value)}))


def split_values(value):
    return {item for item in re.split(r"[;,]", value or "") if item}


def normalize_pathway(value):
    value = value.strip()
    match = PATH_RE.search(value)
    return f"map{match.group(1)}" if match else ""


def normalize_module(value):
    value = value.strip()
    match = MODULE_RE.search(value)
    return match.group(1) if match else ""


def normalize_ko(value):
    match = KO_RE.search(value or "")
    return match.group(0) if match else ""


def load_names(path: Path, kind: str):
    names = {}
    for fields in read_raw_tsv(path):
        if len(fields) < 2:
            continue
        accession = (
            normalize_pathway(fields[0])
            if kind == "PATHWAY"
            else normalize_module(fields[0])
        )
        if accession:
            names[accession] = fields[1].strip()
    return names


def load_links(path: Path, kind: str):
    links = defaultdict(set)
    for fields in read_raw_tsv(path):
        if len(fields) < 2:
            continue
        ko = next((normalize_ko(value) for value in fields if normalize_ko(value)), "")
        if kind == "PATHWAY":
            target = next(
                (normalize_pathway(value) for value in fields if normalize_pathway(value)),
                "",
            )
        else:
            target = next(
                (normalize_module(value) for value in fields if normalize_module(value)),
                "",
            )
        if ko and target:
            links[ko].add(target)
    return links


def load_rules(path: Path):
    rules = []
    for number, row in enumerate(read_tsv(path), start=2):
        if row.get("rule_type") != "PATHWAY_REGEX" or row.get("strength") != "core":
            continue
        try:
            regex = re.compile(row["pattern"], flags=re.IGNORECASE)
        except re.error as error:
            raise SystemExit(f"ERROR: invalid pathway regex on line {number}: {error}")
        rules.append({**row, "regex": regex, "rule_number": number})
    if not rules:
        raise SystemExit("ERROR: no core PATHWAY_REGEX rules were loaded")
    return rules


def excluded_pathway(accession, name):
    match = re.search(r"(\d{5})$", accession)
    number = int(match.group(1)) if match else -1
    if any(start <= number <= end for start, end in GLOBAL_PATHWAY_RANGES):
        return "GLOBAL_OR_OVERVIEW_MAP"
    if EXCLUDED_NAME_RE.search(name):
        return "DISEASE_OR_CONTEXT_SPECIFIC_MAP"
    return ""


def match_name(name, rules):
    return [rule for rule in rules if rule["regex"].search(name or "")]


def file_sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_selected_fasta(source: Path, output: Path, orthogroups):
    output.parent.mkdir(parents=True, exist_ok=True)
    written = 0
    if not source.is_file():
        output.write_text("", encoding="utf-8")
        return written

    header = None
    parts = []

    def save(out_handle, record_header, sequence_parts):
        if record_header is None:
            return 0
        token = record_header.split()[0]
        orthogroup = token.split("|", 1)[0]
        if orthogroup not in orthogroups:
            return 0
        out_handle.write(f">{record_header}\n")
        sequence = "".join(sequence_parts)
        for start in range(0, len(sequence), 80):
            out_handle.write(sequence[start : start + 80] + "\n")
        return 1

    with source.open(encoding="utf-8", errors="replace") as inp, output.open(
        "w", encoding="utf-8"
    ) as out:
        for raw in inp:
            line = raw.strip()
            if line.startswith(">"):
                written += save(out, header, parts)
                header = line[1:].strip()
                parts = []
            elif header is not None:
                parts.append(line)
        written += save(out, header, parts)
    return written


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--blastkoala-complete", type=Path, required=True)
    parser.add_argument("--stage23-accepted", type=Path, required=True)
    parser.add_argument("--membership", type=Path, required=True)
    parser.add_argument("--rules", type=Path, required=True)
    parser.add_argument("--kegg-pathway-list", type=Path, required=True)
    parser.add_argument("--kegg-pathway-links", type=Path, required=True)
    parser.add_argument("--kegg-module-list", type=Path, required=True)
    parser.add_argument("--kegg-module-links", type=Path, required=True)
    parser.add_argument("--stage23-fasta", type=Path)
    parser.add_argument("--blastkoala-fasta", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    required = [
        args.blastkoala_complete,
        args.stage23_accepted,
        args.membership,
        args.rules,
        args.kegg_pathway_list,
        args.kegg_pathway_links,
        args.kegg_module_list,
        args.kegg_module_links,
    ]
    for path in required:
        if not path.is_file():
            raise SystemExit(f"ERROR: required input not found: {path}")

    rules = load_rules(args.rules)
    pathway_names = load_names(args.kegg_pathway_list, "PATHWAY")
    module_names = load_names(args.kegg_module_list, "MODULE")
    pathway_links = load_links(args.kegg_pathway_links, "PATHWAY")
    module_links = load_links(args.kegg_module_links, "MODULE")

    accepted = {row["orthogroup"]: row for row in read_tsv(args.stage23_accepted)}

    species_by_og = defaultdict(set)
    proteins_by_og = defaultdict(int)
    for row in read_tsv(args.membership):
        orthogroup = row.get("orthogroup", "")
        count = int(row.get("copy_count", "0") or 0)
        if orthogroup and count > 0:
            species_by_og[orthogroup].add(row.get("species", ""))
            proteins_by_og[orthogroup] += count

    ko_by_og = defaultdict(set)
    query_by_og = defaultdict(set)
    status_by_og = defaultdict(set)
    blastkoala_rows = list(read_tsv(args.blastkoala_complete))
    if blastkoala_rows and "KO" not in blastkoala_rows[0]:
        raise SystemExit("ERROR: BlastKOALA complete table must contain a KO header")
    for row in blastkoala_rows:
        orthogroup = row.get("orthogroup", "") or row.get("query_id", "").split("|", 1)[0]
        if not orthogroup:
            continue
        query_by_og[orthogroup].add(row.get("query_id", ""))
        status_by_og[orthogroup].add(row.get("blastkoala_status", ""))
        for ko in KO_RE.findall(row.get("KO", "")):
            ko_by_og[orthogroup].add(ko)

    evidence_rows = []
    relevant_by_og = defaultdict(list)
    catalog_counts = defaultdict(lambda: {"queries": set(), "orthogroups": set(), "kos": set()})

    for orthogroup in sorted(query_by_og):
        for ko in sorted(ko_by_og.get(orthogroup, ())):
            targets = [("PATHWAY", value) for value in sorted(pathway_links.get(ko, ()))]
            targets += [("MODULE", value) for value in sorted(module_links.get(ko, ()))]
            for kind, accession in targets:
                name = pathway_names.get(accession, "") if kind == "PATHWAY" else module_names.get(accession, "")
                exclusion = excluded_pathway(accession, name) if kind == "PATHWAY" else ""
                matches = [] if exclusion else match_name(name, rules)
                themes = unique_join(rule["theme"] for rule in matches)
                relevance = unique_join(rule["relevance_class"] for rule in matches)
                row = {
                    "orthogroup": orthogroup,
                    "query_ids": unique_join(query_by_og[orthogroup]),
                    "ko": ko,
                    "kegg_record_type": kind,
                    "kegg_accession": accession,
                    "kegg_name": name,
                    "is_symbiosis_relevant": int(bool(matches)),
                    "symbiosis_themes": themes,
                    "relevance_classes": relevance,
                    "exclusion_reason": exclusion,
                    "matched_rule_lines": unique_join(rule["rule_number"] for rule in matches),
                    "literature_keys": unique_join(
                        key
                        for rule in matches
                        for key in split_values(rule.get("literature_key", ""))
                    ),
                }
                evidence_rows.append(row)
                if matches:
                    relevant_by_og[orthogroup].append(row)
                    key = (kind, accession, name, themes, relevance)
                    catalog_counts[key]["orthogroups"].add(orthogroup)
                    catalog_counts[key]["kos"].add(ko)
                    catalog_counts[key]["queries"].update(query_by_og[orthogroup])

    evidence_fields = [
        "orthogroup", "query_ids", "ko", "kegg_record_type", "kegg_accession",
        "kegg_name", "is_symbiosis_relevant", "symbiosis_themes",
        "relevance_classes", "exclusion_reason", "matched_rule_lines",
        "literature_keys",
    ]
    write_tsv(args.output_dir / "orthogroup_kegg_evidence.tsv", evidence_fields, evidence_rows)

    catalog_rows = []
    for (kind, accession, name, themes, relevance), counts in sorted(catalog_counts.items()):
        catalog_rows.append({
            "kegg_record_type": kind,
            "kegg_accession": accession,
            "kegg_name": name,
            "symbiosis_themes": themes,
            "relevance_classes": relevance,
            "orthogroup_count": len(counts["orthogroups"]),
            "query_count": len(counts["queries"]),
            "ko_count": len(counts["kos"]),
            "orthogroups": unique_join(counts["orthogroups"]),
            "kos": unique_join(counts["kos"]),
        })
    catalog_fields = [
        "kegg_record_type", "kegg_accession", "kegg_name", "symbiosis_themes",
        "relevance_classes", "orthogroup_count", "query_count", "ko_count",
        "orthogroups", "kos",
    ]
    write_tsv(args.output_dir / "kegg_symbiosis_catalog.tsv", catalog_fields, catalog_rows)

    validation_rows = []
    stage23_rows = []
    corroborated_rows = []
    review_rows = []
    all_orthogroups = sorted(set(query_by_og) | set(accepted))
    for orthogroup in all_orthogroups:
        stage = accepted.get(orthogroup)
        relevant = relevant_by_og.get(orthogroup, [])
        kegg_themes = {theme for item in relevant for theme in split_values(item["symbiosis_themes"])}
        stage_themes = split_values(stage.get("symbiosis_themes", "")) if stage else set()
        overlap = stage_themes & kegg_themes
        kos = ko_by_og.get(orthogroup, set())

        if stage:
            if not kos:
                label = "NO_KO"
            elif relevant and overlap:
                sources = split_values(stage.get("evidence_sources", ""))
                label = "KEGG_STRONG" if "INTERPRO" in sources else "KEGG_SUPPORTED"
            elif relevant:
                label = "KEGG_DISCORDANT"
            else:
                label = "NO_RELEVANT_KEGG"
        elif relevant:
            label = "KEGG_REVIEW"
        else:
            continue

        row = {
            "orthogroup": orthogroup,
            "kegg_validation_label": label,
            "stage23_selection_status": stage.get("selection_status", "") if stage else "NOT_ACCEPTED",
            "stage23_evidence_grade": stage.get("evidence_grade", "") if stage else "",
            "stage23_themes": unique_join(stage_themes),
            "kegg_themes": unique_join(kegg_themes),
            "concordant_themes": unique_join(overlap),
            "ko_assignments": unique_join(kos),
            "relevant_kegg_records": unique_join(
                f'{item["kegg_accession"]}|{item["kegg_name"]}' for item in relevant
            ),
            "blastkoala_status": unique_join(status_by_og.get(orthogroup, set())),
            "member_species_count": len(species_by_og.get(orthogroup, set())),
            "member_species": unique_join(species_by_og.get(orthogroup, set())),
            "member_protein_count": proteins_by_og.get(orthogroup, 0),
            "interpretation": {
                "KEGG_STRONG": "Concordant KEGG theme plus Stage 23 GO and InterPro evidence",
                "KEGG_SUPPORTED": "Concordant KEGG theme plus Stage 23 evidence",
                "KEGG_DISCORDANT": "Relevant KEGG annotation, but its theme differs from Stage 23",
                "NO_RELEVANT_KEGG": "KO assigned, but no predefined symbiosis-relevant KEGG record",
                "NO_KO": "No BlastKOALA KO assignment",
                "KEGG_REVIEW": "KEGG-only lead; requires independent annotation and literature review",
            }[label],
        }
        validation_rows.append(row)
        if stage:
            stage23_rows.append(row)
        if label in {"KEGG_STRONG", "KEGG_SUPPORTED"}:
            corroborated_rows.append(row)
        elif label == "KEGG_REVIEW":
            review_rows.append(row)

    validation_fields = [
        "orthogroup", "kegg_validation_label", "stage23_selection_status",
        "stage23_evidence_grade", "stage23_themes", "kegg_themes",
        "concordant_themes", "ko_assignments", "relevant_kegg_records",
        "blastkoala_status", "member_species_count", "member_species",
        "member_protein_count", "interpretation",
    ]
    write_tsv(args.output_dir / "stage23_kegg_validation.tsv", validation_fields, stage23_rows)
    write_tsv(args.output_dir / "kegg_corroborated_candidates.tsv", validation_fields, corroborated_rows)
    write_tsv(args.output_dir / "kegg_only_review_candidates.tsv", validation_fields, review_rows)

    accepted_fasta_count = write_selected_fasta(
        args.stage23_fasta or Path("/nonexistent"),
        args.output_dir / "kegg_corroborated_proteins.faa",
        {row["orthogroup"] for row in corroborated_rows},
    )
    review_fasta_count = write_selected_fasta(
        args.blastkoala_fasta or Path("/nonexistent"),
        args.output_dir / "kegg_only_review_representatives.faa",
        {row["orthogroup"] for row in review_rows},
    )

    label_counts = defaultdict(int)
    for row in validation_rows:
        label_counts[row["kegg_validation_label"]] += 1
    summary_rows = [
        {"metric": "blastkoala_rows", "value": len(blastkoala_rows)},
        {"metric": "orthogroups_with_ko", "value": len(ko_by_og)},
        {"metric": "stage23_accepted_orthogroups", "value": len(accepted)},
        {"metric": "symbiosis_relevant_kegg_records", "value": len(catalog_rows)},
        {"metric": "kegg_corroborated_orthogroups", "value": len(corroborated_rows)},
        {"metric": "kegg_only_review_orthogroups", "value": len(review_rows)},
        {"metric": "corroborated_fasta_records", "value": accepted_fasta_count},
        {"metric": "review_fasta_records", "value": review_fasta_count},
    ]
    summary_rows += [
        {"metric": f"label_{label}", "value": count}
        for label, count in sorted(label_counts.items())
    ]
    for label, path in [
        ("kegg_pathway_list_sha256", args.kegg_pathway_list),
        ("kegg_pathway_links_sha256", args.kegg_pathway_links),
        ("kegg_module_list_sha256", args.kegg_module_list),
        ("kegg_module_links_sha256", args.kegg_module_links),
    ]:
        summary_rows.append({"metric": label, "value": file_sha256(path)})
    write_tsv(args.output_dir / "run_summary.tsv", ["metric", "value"], summary_rows)

    readme = """# KEGG cross-validation of Stage 23 candidates

This directory compares representative-protein BlastKOALA KO assignments with
KEGG pathway/module membership and the predefined literature rules used in
Stage 23. It is an annotation-concordance screen, not functional enrichment,
experimental validation, or proof that an orthogroup functions in symbiosis.

`KEGG_STRONG` means that a KEGG theme agrees with Stage 23 and Stage 23 also
contains InterPro evidence. `KEGG_SUPPORTED` means the KEGG theme agrees with
Stage 23 without independent InterPro support. `KEGG_REVIEW` is a KEGG-only
lead and must not be merged into the accepted list without manual review.
`NO_KO` and `NO_RELEVANT_KEGG` are missing/negative annotation outcomes, not
evidence that the protein lacks a symbiosis role.

Global/overview metabolic maps and disease/context-specific maps are excluded
from positive corroboration. Stage 23 evidence grades are preserved unchanged.
MetaCyc can be resolved later as a separate annotation source.
"""
    (args.output_dir / "README.md").write_text(readme, encoding="utf-8")

    print(f"BlastKOALA representatives: {len(blastkoala_rows)}")
    print(f"Orthogroups with KO: {len(ko_by_og)}")
    print(f"KEGG-corroborated Stage 23 candidates: {len(corroborated_rows)}")
    print(f"KEGG-only review leads: {len(review_rows)}")
    print(f"Output: {args.output_dir.resolve()}")


if __name__ == "__main__":
    raise SystemExit(main())
