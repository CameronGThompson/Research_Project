#!/usr/bin/env python3
"""Validate the packaged evidence chain and key reported totals."""

from __future__ import annotations

import csv
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def overall_statistics(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.reader(handle, delimiter="\t"):
            if len(row) >= 2:
                values[row[0]] = row[1]
    return values


def require(path: str) -> Path:
    target = ROOT / path
    if not target.is_file() or target.stat().st_size == 0:
        raise AssertionError(f"Missing or empty required file: {path}")
    return target


def main() -> int:
    required = [
        "data/orthofinder/Statistics_Overall.tsv",
        "data/orthofinder/Statistics_PerSpecies.tsv",
        "data/orthofinder/SpeciesTree_rooted.txt",
        "data/candidates/candidate_master.tsv",
        "data/candidates/candidate_membership.long.tsv",
        "data/candidates/absence_validation.tsv",
        "data/annotation/candidate_annotations.tsv",
        "data/enrichment/functional_enrichment.tsv",
        "data/final_candidates/Figure_5_candidate_evidence_data.tsv",
        "data/final_candidates/final_candidate_summary.tsv",
        "data/supplementary/Table_S2_candidate_orthogroups.xlsx",
        "data/supplementary/Table_S3_complete_functional_enrichment.xlsx",
        "figures/candidates/figure3_candidate_distribution_validation.png",
        "figures/enrichment/Figure_4_functional_enrichment_dotplot.png",
        "figures/final_candidates/Figure_5_final_candidate_evidence_matrix.png",
    ]
    for item in required:
        require(item)

    overall = overall_statistics(ROOT / "data/orthofinder/Statistics_Overall.tsv")
    expected_overall = {
        "Number of species": "15",
        "Number of genes": "442747",
        "Number of genes in orthogroups": "421353",
        "Number of unassigned genes": "21394",
        "Percentage of genes in orthogroups": "95.2",
        "Number of orthogroups": "32438",
    }
    for key, value in expected_overall.items():
        assert overall.get(key) == value, (key, overall.get(key), value)

    candidates = read_tsv(ROOT / "data/candidates/candidate_master.tsv")
    assert len(candidates) == 2864
    assert sum(int(row["tier__symbiotic_only_replicated"]) for row in candidates) == 1368
    assert sum(int(row["tier__symbiotic_only_cross_lineage"]) for row in candidates) == 250
    assert sum(int(row["tier__symbiotic_only_broad"]) for row in candidates) == 32
    assert sum(int(row["tier__symbiotic_only_universal"]) for row in candidates) == 0

    validation = read_tsv(ROOT / "data/candidates/absence_validation.tsv")
    assert len(validation) == 2864
    statuses = Counter(row["absence_status"] for row in validation)
    assert statuses == {
        "FLAG_HOMOLOG_DETECTED": 1828,
        "NO_HMM_HIT_AT_THRESHOLDS": 1036,
    }

    final = read_tsv(ROOT / "data/final_candidates/final_candidate_summary.tsv")
    assert len(final) == 12
    tiers = Counter(row["report_tier"] for row in final)
    assert tiers == {"PRIMARY": 4, "SECONDARY": 8}

    matrix = read_tsv(ROOT / "data/final_candidates/Figure_5_candidate_evidence_data.tsv")
    species_columns = [
        "Anthopleura_xanthogrammica",
        "Condylactis_gigantea",
        "Oculina_patagonica",
        "Pocillopora_damicornis",
        "Stylophora_pistillata",
        "Hydra_viridissima",
        "Cassiopea_sp",
        "Mastigias_papua",
    ]
    proteins = sum(int(row[column]) for row in matrix for column in species_columns)
    occurrences = sum(int(row[column]) > 0 for row in matrix for column in species_columns)
    assert proteins == 36
    assert occurrences == 23

    print("Package validation passed")
    print("  OrthoFinder: 15 species, 442,747 proteins, 32,438 orthogroups")
    print("  Candidates: 2,864 total; 1,368 replicated; 1,036 HMM-strict")
    print("  Final report: 12 orthogroups; 36 proteins; 23 species occurrences")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, KeyError, ValueError) as error:
        print(f"Validation failed: {error}", file=sys.stderr)
        raise SystemExit(1)

