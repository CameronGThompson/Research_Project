#!/usr/bin/env python3
"""Write SHA-256 and size metadata for packaged data and figures."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "DATA_MANIFEST.tsv"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> int:
    files = sorted(
        path
        for directory in (ROOT / "config", ROOT / "data", ROOT / "figures")
        for path in directory.rglob("*")
        if path.is_file()
    )
    with OUTPUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["relative_path", "size_bytes", "sha256"])
        for path in files:
            writer.writerow([path.relative_to(ROOT), path.stat().st_size, digest(path)])
    print(f"Wrote {len(files)} entries to {OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

