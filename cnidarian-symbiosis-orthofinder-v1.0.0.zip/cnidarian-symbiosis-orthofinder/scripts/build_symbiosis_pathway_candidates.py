#!/usr/bin/env python3
"""Build a literature-guided list of symbiosis-pathway candidate orthogroups.

This is a pathway-membership screen, not a functional-enrichment test.  It uses
the representative InterProScan annotations already generated for each
candidate orthogroup, then restores all orthogroup members and species from the
candidate membership table.
"""

from __future__ import annotations

import argparse
import csv
import html
import os
import re
import sys
from collections import defaultdict
from pathlib import Path


def read_tsv(path: Path):
    """Read a TSV while tolerating blank lines and comments before the header."""
    with path.open(encoding="utf-8", errors="replace", newline="") as handle:
        lines = (line for line in handle if line.strip() and not line.startswith("#"))
        yield from csv.DictReader(lines, delimiter="\t")


def write_tsv(path: Path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            delimiter="\t",
            fieldnames=fieldnames,
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def require_file(path: Path, label: str):
    if not path.is_file():
        raise SystemExit(f"ERROR: {label} not found: {path}")


def first_column(fieldnames, candidates, required=True):
    by_lower = {name.lower(): name for name in fieldnames if name}
    for candidate in candidates:
        if candidate.lower() in by_lower:
            return by_lower[candidate.lower()]
    if required:
        raise SystemExit(
            "ERROR: none of these columns was found: " + ", ".join(candidates)
        )
    return None


def query_parts(query_id: str):
    parts = query_id.split("|")
    if len(parts) >= 3:
        return parts[0], parts[1], "|".join(parts[2:])
    return (parts[0] if parts else ""), "", query_id


def normalize_go(value: str):
    match = re.search(r"GO:\d{7}", value or "")
    return match.group(0) if match else ""


def clean_name(value: str):
    value = html.unescape(value or "")
    value = re.sub(r"<[^>]+>", "", value)
    return re.sub(r"\s+", " ", value).strip()


def load_obo(path: Path):
    names = {}
    parents = defaultdict(set)
    obsolete = set()
    if not path.is_file():
        return names, parents, obsolete

    current = None
    stanza = None
    with path.open(encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\n")
            if line == "[Term]":
                stanza = "Term"
                current = None
            elif line.startswith("["):
                stanza = None
                current = None
            elif stanza == "Term" and line.startswith("id: GO:"):
                current = line.split("id: ", 1)[1]
            elif stanza == "Term" and current and line.startswith("name: "):
                names[current] = line.split("name: ", 1)[1]
            elif stanza == "Term" and current and line.startswith("is_a: GO:"):
                parents[current].add(line.split()[1])
            elif stanza == "Term" and current and line.startswith("relationship: part_of GO:"):
                parents[current].add(line.split()[2])
            elif stanza == "Term" and current and line == "is_obsolete: true":
                obsolete.add(current)
    return names, parents, obsolete


def ancestors(term: str, parents, cache):
    if term in cache:
        return cache[term]
    found = {term}
    stack = [term]
    while stack:
        child = stack.pop()
        for parent in parents.get(child, ()):
            if parent not in found:
                found.add(parent)
                stack.append(parent)
    cache[term] = found
    return found


def load_reactome_names(path: Path):
    names = {}
    if not path.is_file():
        return names
    with path.open(encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            fields = raw.rstrip("\n").split("\t")
            if len(fields) >= 2 and fields[0].startswith("R-"):
                names[("Reactome", fields[0])] = clean_name(fields[1])
    return names


def load_metacyc_names(path: Path):
    names = {}
    if not path.is_file():
        return names
    accession = None
    common_name = None
    with path.open(encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\n")
            if line.startswith("UNIQUE-ID - "):
                accession = line.split(" - ", 1)[1]
            elif line.startswith("COMMON-NAME - "):
                common_name = clean_name(line.split(" - ", 1)[1])
            elif line == "//":
                if accession and common_name:
                    names[("MetaCyc", accession)] = common_name
                accession = None
                common_name = None
    if accession and common_name:
        names[("MetaCyc", accession)] = common_name
    return names


def load_rules(path: Path):
    rules = []
    for number, row in enumerate(read_tsv(path), start=2):
        rule_type = row.get("rule_type", "")
        pattern = row.get("pattern", "")
        item = dict(row)
        item["rule_number"] = number
        item["regex"] = None
        if rule_type.endswith("_REGEX"):
            try:
                item["regex"] = re.compile(pattern, flags=re.IGNORECASE)
            except re.error as error:
                raise SystemExit(f"ERROR: invalid regex on rule line {number}: {error}")
        rules.append(item)
    return rules


def unique_join(values, separator=";"):
    return separator.join(sorted({str(value) for value in values if str(value)}))


def locate_proteome(project_root: Path, configured: str, extra_dirs):
    configured_path = Path(configured)
    if configured_path.is_file():
        return configured_path

    filename = configured_path.name
    roots = [Path(value) for value in extra_dirs]
    roots += [
        project_root / "proteomes",
        project_root / "input" / "proteomes",
        project_root / "inputs" / "proteomes",
        project_root / "data" / "proteomes",
        project_root / "results" / "proteome_qc",
        project_root / "results" / "qc",
    ]
    for root in roots:
        direct = root / configured
        if direct.is_file():
            return direct
        direct = root / filename
        if direct.is_file():
            return direct

    skip = {".git", ".checkpoints", "logs", "software", "interproscan"}
    for current, dirs, files in os.walk(project_root):
        dirs[:] = [name for name in dirs if name not in skip]
        if filename in files:
            return Path(current) / filename
    return None


def fasta_aliases(header: str):
    token = header.split()[0]
    aliases = {token}
    aliases.update(part for part in token.split("|") if part)
    aliases.update(re.sub(r"\.\d+$", "", value) for value in list(aliases))
    return aliases


def extract_fasta(path: Path, wanted):
    found = {}
    header = None
    parts = []
    wanted_by_alias = defaultdict(set)
    for wanted_id in wanted:
        wanted_by_alias[wanted_id].add(wanted_id)
        wanted_by_alias[re.sub(r"\.\d+$", "", wanted_id)].add(wanted_id)

    def save_record(record_header, sequence_parts):
        if record_header is None:
            return
        aliases = fasta_aliases(record_header)
        matched = set()
        for alias in aliases:
            matched.update(wanted_by_alias.get(alias, ()))
        if matched:
            sequence = "".join(sequence_parts).upper()
            for wanted_id in matched:
                found[wanted_id] = sequence

    opener = path.open
    if path.suffix == ".gz":
        import gzip
        opener = lambda **kwargs: gzip.open(path, mode="rt", **kwargs)

    with opener(encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.strip()
            if line.startswith(">"):
                save_record(header, parts)
                header = line[1:].strip()
                parts = []
            else:
                parts.append(line)
    save_record(header, parts)
    return found


def wrap_fasta(sequence: str, width=60):
    return "\n".join(sequence[index:index + width] for index in range(0, len(sequence), width))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path("."))
    parser.add_argument("--query-summary", type=Path)
    parser.add_argument("--pathway-assignments", type=Path)
    parser.add_argument("--go-assignments", type=Path)
    parser.add_argument("--interpro-assignments", type=Path)
    parser.add_argument("--candidate-membership", type=Path)
    parser.add_argument("--species", type=Path)
    parser.add_argument("--rules", type=Path)
    parser.add_argument("--go-obo", type=Path)
    parser.add_argument("--reactome-pathways", type=Path)
    parser.add_argument("--metacyc-pathways-dat", type=Path)
    parser.add_argument("--proteome-dir", action="append", default=[])
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--skip-fasta", action="store_true")
    args = parser.parse_args()

    root = args.project_root.resolve()
    summary_dir = root / "results" / "interproscan" / "candidates" / "summary"
    args.query_summary = args.query_summary or summary_dir / "query_summary.tsv"
    args.pathway_assignments = args.pathway_assignments or summary_dir / "pathway_assignments.tsv"
    args.go_assignments = args.go_assignments or summary_dir / "go_assignments.tsv"
    args.interpro_assignments = args.interpro_assignments or summary_dir / "interpro_assignments.tsv"
    args.candidate_membership = args.candidate_membership or root / "results" / "candidates" / "candidate_membership.long.tsv"
    args.species = args.species or root / "config" / "species.tsv"
    args.rules = args.rules or root / "config" / "symbiosis_process_rules.tsv"
    args.go_obo = args.go_obo or root / "resources" / "symbiosis_pathways" / "go-basic.obo"
    args.reactome_pathways = args.reactome_pathways or root / "resources" / "symbiosis_pathways" / "ReactomePathways.txt"
    args.metacyc_pathways_dat = args.metacyc_pathways_dat or root / "resources" / "symbiosis_pathways" / "pathways.dat"
    args.output_dir = args.output_dir or root / "results" / "symbiosis_pathway_candidates"

    for path, label in [
        (args.query_summary, "query summary"),
        (args.pathway_assignments, "pathway assignments"),
        (args.go_assignments, "GO assignments"),
        (args.interpro_assignments, "InterPro assignments"),
        (args.candidate_membership, "candidate membership"),
        (args.species, "species table"),
        (args.rules, "symbiosis rules"),
    ]:
        require_file(path, label)

    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)

    rules = load_rules(args.rules)
    go_rules = [row for row in rules if row["rule_type"] == "GO_DESCENDANT"]
    pathway_rules = [row for row in rules if row["rule_type"] == "PATHWAY_REGEX"]
    interpro_rules = [row for row in rules if row["rule_type"] == "INTERPRO_REGEX"]

    go_names, go_parents, obsolete_go = load_obo(args.go_obo)
    ancestor_cache = {}
    pathway_names = {}
    pathway_names.update(load_reactome_names(args.reactome_pathways))
    pathway_names.update(load_metacyc_names(args.metacyc_pathways_dat))

    species_rows = list(read_tsv(args.species))
    if not species_rows:
        raise SystemExit(f"ERROR: no species rows in {args.species}")
    species_fields = list(species_rows[0])
    species_of_col = first_column(species_fields, ["orthofinder_name", "proteome", "proteome_name"])
    species_name_col = first_column(species_fields, ["species", "species_name"], required=False)
    proteome_file_col = first_column(species_fields, ["proteome_file", "fasta", "proteome_path"], required=False)
    species_by_of = {row[species_of_col]: row for row in species_rows if row.get(species_of_col)}

    membership_rows = list(read_tsv(args.candidate_membership))
    if not membership_rows:
        raise SystemExit(f"ERROR: no membership rows in {args.candidate_membership}")
    membership_fields = list(membership_rows[0])
    membership_og_col = first_column(membership_fields, ["orthogroup", "orthogroup_id", "Orthogroup"])
    membership_of_col = first_column(
        membership_fields,
        ["orthofinder_name", "proteome", "proteome_name", "species_file"],
    )
    membership_protein_col = first_column(
        membership_fields,
        ["original_protein_id", "protein_id", "member_id", "sequence_id", "gene_id"],
        required=False,
    )
    membership_members_col = first_column(
        membership_fields,
        ["member_ids", "protein_ids", "sequence_ids", "gene_ids", "members"],
        required=False,
    )
    membership_copy_col = first_column(
        membership_fields,
        ["copy_count", "member_count", "protein_count"],
        required=False,
    )
    membership_species_col = first_column(
        membership_fields,
        ["species", "species_name"],
        required=False,
    )
    if membership_protein_col is None and membership_members_col is None:
        raise SystemExit(
            "ERROR: candidate membership needs either a single-protein column "
            "or a comma-separated member_ids column"
        )

    members_by_og = defaultdict(list)
    membership_count_errors = []
    for row in membership_rows:
        og = row.get(membership_og_col, "")
        of_name = row.get(membership_of_col, "")
        if not og or not of_name:
            continue

        if membership_members_col is not None:
            raw_members = row.get(membership_members_col, "")
            proteins = [value.strip() for value in raw_members.split(",") if value.strip()]
        else:
            protein = row.get(membership_protein_col, "")
            proteins = [protein.strip()] if protein.strip() else []

        if membership_copy_col is not None:
            raw_count = row.get(membership_copy_col, "").strip()
            expected_count = int(raw_count or 0)
            if expected_count != len(proteins):
                membership_count_errors.append(
                    (og, of_name, expected_count, len(proteins))
                )

        configured_species = (
            species_by_of.get(of_name, {}).get(species_name_col, "")
            if species_name_col else ""
        )
        supplied_species = (
            row.get(membership_species_col, "").strip()
            if membership_species_col else ""
        )
        species_name = supplied_species or configured_species or of_name

        for protein in proteins:
            members_by_og[og].append(
                {
                    "orthogroup": og,
                    "orthofinder_name": of_name,
                    "species": species_name,
                    "protein_id": protein,
                }
            )

    if membership_count_errors:
        examples = "; ".join(
            f"{og}/{of_name}: expected {expected}, parsed {observed}"
            for og, of_name, expected, observed in membership_count_errors[:10]
        )
        raise SystemExit(
            f"ERROR: copy_count disagrees with parsed member_ids in "
            f"{len(membership_count_errors)} rows. Examples: {examples}"
        )

    pathways_by_query = defaultdict(list)
    pathway_catalog_counts = defaultdict(lambda: {"queries": set(), "orthogroups": set()})
    for row in read_tsv(args.pathway_assignments):
        query = row.get("query_id", "")
        database = row.get("pathway_database", "")
        accession = row.get("pathway_accession", "")
        if not query or not database or not accession:
            continue
        pathways_by_query[query].append((database, accession))
        og = query_parts(query)[0]
        pathway_catalog_counts[(database, accession)]["queries"].add(query)
        pathway_catalog_counts[(database, accession)]["orthogroups"].add(og)

    go_by_query = defaultdict(set)
    for row in read_tsv(args.go_assignments):
        query = row.get("query_id", "")
        go_id = normalize_go(row.get("go_id", ""))
        if query and go_id:
            go_by_query[query].add(go_id)

    interpro_by_query = defaultdict(list)
    for row in read_tsv(args.interpro_assignments):
        query = row.get("query_id", "")
        accession = row.get("interpro_accession", "")
        description = row.get("interpro_description", "")
        if query and (accession or description):
            interpro_by_query[query].append((accession, description))

    evidence_by_og = defaultdict(list)
    representative_by_og = {}

    def add_evidence(og, query, source, accession, description, rule):
        evidence_by_og[og].append(
            {
                "orthogroup": og,
                "query_id": query,
                "theme": rule["theme"],
                "relevance_class": rule["relevance_class"],
                "source": source,
                "accession": accession,
                "description": clean_name(description),
                "strength": rule["strength"],
                "matched_rule": rule["pattern"],
                "rationale": rule["rationale"],
                "literature_key": rule["literature_key"],
                "rule_number": rule["rule_number"],
            }
        )

    query_rows = list(read_tsv(args.query_summary))
    for row in query_rows:
        query = row.get("query_id", "")
        og = row.get("orthogroup", "") or query_parts(query)[0]
        if not query or not og:
            continue
        representative_by_og[og] = query

        for go_id in sorted(go_by_query.get(query, ())):
            go_ancestors = ancestors(go_id, go_parents, ancestor_cache) if go_parents else {go_id}
            for rule in go_rules:
                if rule["pattern"] in go_ancestors:
                    add_evidence(og, query, "GO", go_id, go_names.get(go_id, ""), rule)

        for database, accession in pathways_by_query.get(query, ()):
            name = pathway_names.get((database, accession), "")
            if not name:
                continue
            for rule in pathway_rules:
                if rule["regex"].search(name):
                    add_evidence(
                        og,
                        query,
                        "PATHWAY",
                        f"{database}:{accession}",
                        name,
                        rule,
                    )

        interpro_terms = list(interpro_by_query.get(query, ()))
        signature_text = row.get("signatures", "")
        if signature_text:
            interpro_terms.append(("QUERY_SIGNATURES", signature_text))
        seen_interpro_matches = set()
        for accession, description in interpro_terms:
            for rule in interpro_rules:
                if rule["regex"].search(description or ""):
                    key = (accession, description, rule["theme"], rule["pattern"])
                    if key not in seen_interpro_matches:
                        add_evidence(og, query, "INTERPRO", accession, description, rule)
                        seen_interpro_matches.add(key)

    # Remove exact duplicate evidence generated by repeated annotation rows.
    for og, rows in list(evidence_by_og.items()):
        deduplicated = {}
        for row in rows:
            key = (
                row["query_id"], row["theme"], row["source"], row["accession"],
                row["description"], row["strength"], row["matched_rule"],
            )
            deduplicated[key] = row
        evidence_by_og[og] = list(deduplicated.values())

    accepted = set()
    review_only = set()
    summary_rows = []
    for og in sorted(evidence_by_og):
        evidence = evidence_by_og[og]
        core = [row for row in evidence if row["strength"] == "core" and row["source"] in {"GO", "PATHWAY"}]
        supporting = [row for row in evidence if row["strength"] == "supporting"]
        source_types = {row["source"] for row in evidence}

        if core:
            accepted.add(og)
            if {"GO", "PATHWAY"}.issubset(source_types):
                grade = "A_multi_source"
            elif supporting:
                grade = "B_core_plus_support"
            else:
                grade = "C_single_core_source"
            status = "ACCEPTED"
        else:
            review_only.add(og)
            grade = "REVIEW_supporting_only"
            status = "REVIEW"

        members = members_by_og.get(og, [])
        member_species = {row["species"] for row in members}
        query = representative_by_og.get(og, "")
        representative_species = query_parts(query)[1]
        representative_species = species_by_of.get(representative_species, {}).get(species_name_col, representative_species) if species_name_col else representative_species
        pathway_terms = [
            f"{row['accession']}|{row['description']}" for row in evidence if row["source"] == "PATHWAY"
        ]
        go_terms = [
            f"{row['accession']}|{row['description']}" for row in evidence if row["source"] == "GO"
        ]
        interpro_terms = [
            f"{row['accession']}|{row['description']}" for row in evidence if row["source"] == "INTERPRO"
        ]
        summary_rows.append(
            {
                "orthogroup": og,
                "selection_status": status,
                "evidence_grade": grade,
                "relevance_classes": unique_join(row["relevance_class"] for row in evidence),
                "symbiosis_themes": unique_join(row["theme"] for row in evidence),
                "evidence_sources": unique_join(row["source"] for row in evidence),
                "has_pathway_evidence": int(any(row["source"] == "PATHWAY" for row in evidence)),
                "matched_pathways": unique_join(pathway_terms),
                "matched_go_terms": unique_join(go_terms),
                "matched_interpro_entries": unique_join(interpro_terms),
                "representative_query_id": query,
                "representative_species": representative_species,
                "member_species_count": len(member_species),
                "member_species": unique_join(member_species),
                "member_protein_count": len(members),
                "literature_keys": unique_join(
                    key
                    for row in evidence
                    for key in row["literature_key"].split(";")
                ),
            }
        )

    accepted_rows = [row for row in summary_rows if row["selection_status"] == "ACCEPTED"]
    review_rows = [row for row in summary_rows if row["selection_status"] == "REVIEW"]
    summary_fields = [
        "orthogroup", "selection_status", "evidence_grade", "relevance_classes",
        "symbiosis_themes", "evidence_sources", "has_pathway_evidence",
        "matched_pathways", "matched_go_terms", "matched_interpro_entries",
        "representative_query_id", "representative_species", "member_species_count",
        "member_species", "member_protein_count", "literature_keys",
    ]
    write_tsv(out / "candidate_orthogroups.tsv", summary_fields, accepted_rows)
    write_tsv(out / "review_orthogroups.tsv", summary_fields, review_rows)

    evidence_fields = [
        "orthogroup", "query_id", "theme", "relevance_class", "source",
        "accession", "description", "strength", "matched_rule", "rationale",
        "literature_key", "rule_number", "selection_status",
    ]
    evidence_rows = []
    for og in sorted(evidence_by_og):
        status = "ACCEPTED" if og in accepted else "REVIEW"
        for row in sorted(
            evidence_by_og[og],
            key=lambda value: (value["theme"], value["source"], value["accession"]),
        ):
            evidence_rows.append({**row, "selection_status": status})
    write_tsv(out / "filtering_audit.tsv", evidence_fields, evidence_rows)
    write_tsv(
        out / "candidate_evidence.long.tsv",
        evidence_fields,
        [row for row in evidence_rows if row["selection_status"] == "ACCEPTED"],
    )

    pathway_catalog_rows = []
    for (database, accession), counts in sorted(pathway_catalog_counts.items()):
        name = pathway_names.get((database, accession), "")
        matching_rules = [rule for rule in pathway_rules if name and rule["regex"].search(name)]
        pathway_catalog_rows.append(
            {
                "pathway_database": database,
                "pathway_accession": accession,
                "pathway_name": name,
                "name_resolution_status": "RESOLVED" if name else "UNRESOLVED",
                "annotated_queries": len(counts["queries"]),
                "annotated_orthogroups": len(counts["orthogroups"]),
                "symbiosis_related": int(bool(matching_rules)),
                "symbiosis_themes": unique_join(rule["theme"] for rule in matching_rules),
                "rule_strengths": unique_join(rule["strength"] for rule in matching_rules),
            }
        )
    write_tsv(
        out / "all_pathways_catalog.tsv",
        [
            "pathway_database", "pathway_accession", "pathway_name",
            "name_resolution_status", "annotated_queries", "annotated_orthogroups",
            "symbiosis_related", "symbiosis_themes", "rule_strengths",
        ],
        pathway_catalog_rows,
    )

    selected_members = []
    themes_by_og = {
        row["orthogroup"]: row["symbiosis_themes"].split(";")
        for row in accepted_rows
    }
    for og in sorted(accepted):
        for member in members_by_og.get(og, []):
            selected_members.append(
                {**member, "symbiosis_themes": ";".join(themes_by_og.get(og, []))}
            )
    write_tsv(
        out / "candidate_protein_members.tsv",
        ["orthogroup", "orthofinder_name", "species", "protein_id", "symbiosis_themes"],
        selected_members,
    )

    species_order = [
        row.get(species_name_col, "") or row.get(species_of_col, "")
        for row in species_rows
        if row.get(species_of_col)
    ]
    matrix_rows = []
    for og in sorted(accepted):
        counts = defaultdict(int)
        for member in members_by_og.get(og, []):
            counts[member["species"]] += 1
        matrix_rows.append(
            {
                "orthogroup": og,
                "symbiosis_themes": ";".join(themes_by_og.get(og, [])),
                **{species: counts[species] for species in species_order},
            }
        )
    write_tsv(
        out / "orthogroup_species_matrix.tsv",
        ["orthogroup", "symbiosis_themes", *species_order],
        matrix_rows,
    )

    missing_sequence_rows = []
    sequences = {}
    proteome_paths = {}
    if not args.skip_fasta and selected_members:
        wanted_by_of = defaultdict(set)
        for member in selected_members:
            wanted_by_of[member["orthofinder_name"]].add(member["protein_id"])

        for of_name, wanted in sorted(wanted_by_of.items()):
            config = species_by_of.get(of_name, {})
            configured = config.get(proteome_file_col, "") if proteome_file_col else ""
            proteome = locate_proteome(root, configured, args.proteome_dir) if configured else None
            if proteome is None:
                for protein in sorted(wanted):
                    missing_sequence_rows.append(
                        {
                            "orthofinder_name": of_name,
                            "protein_id": protein,
                            "reason": "PROTEOME_NOT_FOUND",
                            "configured_proteome_file": configured,
                        }
                    )
                continue
            proteome_paths[of_name] = proteome
            found = extract_fasta(proteome, wanted)
            for protein in sorted(wanted):
                if protein in found:
                    sequences[(of_name, protein)] = found[protein]
                else:
                    missing_sequence_rows.append(
                        {
                            "orthofinder_name": of_name,
                            "protein_id": protein,
                            "reason": "PROTEIN_NOT_FOUND_IN_FASTA",
                            "configured_proteome_file": str(proteome),
                        }
                    )

        fasta_records = []
        by_theme = defaultdict(list)
        for member in selected_members:
            key = (member["orthofinder_name"], member["protein_id"])
            sequence = sequences.get(key)
            if not sequence:
                continue
            header = (
                f"{member['orthogroup']}|{member['orthofinder_name']}|{member['protein_id']} "
                f"species={member['species']} themes={member['symbiosis_themes']}"
            )
            record = f">{header}\n{wrap_fasta(sequence)}\n"
            fasta_records.append(record)
            for theme in themes_by_og.get(member["orthogroup"], []):
                by_theme[theme].append(record)

        (out / "candidate_proteins.faa").write_text("".join(fasta_records), encoding="utf-8")
        theme_dir = out / "by_theme"
        theme_dir.mkdir(parents=True, exist_ok=True)
        for theme, records in sorted(by_theme.items()):
            (theme_dir / f"{theme}.faa").write_text("".join(records), encoding="utf-8")

    write_tsv(
        out / "missing_sequences.tsv",
        ["orthofinder_name", "protein_id", "reason", "configured_proteome_file"],
        missing_sequence_rows,
    )

    literature_rows = [
        ("Davy2012", "Davy et al. 2012. Cell Biology of Cnidarian-Dinoflagellate Symbiosis.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC3372257/"),
        ("Palmer2012", "Palmer & Traylor-Knowles 2012. Towards an integrated network of coral immune mechanisms.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC3441085/"),
        ("Poole2016", "Poole et al. 2016. Complement component C3 in cnidarian-dinoflagellate symbiosis.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4840205/"),
        ("Neubauer2017", "Neubauer et al. 2017. A diverse host thrombospondin-type-1 repeat protein repertoire promotes symbiont colonization.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC5446238/"),
        ("Weis2019", "Weis 2019. Cell Biology of Coral Symbiosis.", "https://academic.oup.com/icb/article/59/4/845/5509506"),
        ("Tame2023", "Tame et al. 2023. mTORC1 regulates phagosome digestion of symbiotic bacteria in a deep-sea mussel.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC10446485/"),
        ("Dunn2007", "Dunn et al. 2007. Apoptosis and autophagy in cnidarian-dinoflagellate symbiosis.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC2293937/"),
        ("Gorman2025", "Gorman et al. 2025. Stability of cnidarian-dinoflagellate symbiosis and biomass regulation.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC12002341/"),
        ("Matthews2017", "Matthews et al. 2017. Optimal nutrient exchange and immune responses operate in partner specificity.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC5740609/"),
        ("Burriesci2012", "Burriesci et al. 2012. Evidence that glucose is the major transferred metabolite.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC3597287/"),
        ("Roth2014", "Roth 2014. The engine of the reef: photobiology of coral-algal symbiosis.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4141621/"),
        ("Doering2023", "Doering et al. 2023. ROS and RNS in thermal stress-induced cnidarian bleaching.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC10215338/"),
        # Barott2014 is retained as a legacy manifest key; the article was
        # published in the 2015 volume of PNAS.
        ("Barott2014", "Barott et al. 2015. Coral host cells acidify the symbiotic algal microenvironment.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4299235/"),
        ("Zoccola2015", "Zoccola et al. 2015. Bicarbonate transporters in corals.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4650655/"),
    ]
    write_tsv(
        out / "literature_sources.tsv",
        ["literature_key", "citation", "url"],
        [
            {"literature_key": key, "citation": citation, "url": url}
            for key, citation, url in literature_rows
        ],
    )

    unresolved = sum(row["name_resolution_status"] == "UNRESOLVED" for row in pathway_catalog_rows)
    report = f"""# Literature-guided symbiosis pathway candidate screen

This directory is deliberately separate from functional enrichment. It reports
candidate orthogroups whose representative annotations match curated cellular
processes implicated in cnidarian-dinoflagellate symbiosis.

## Run summary

- Candidate orthogroups examined: {len(query_rows)}
- Accepted orthogroups (core GO or named-pathway evidence): {len(accepted_rows)}
- Review-only orthogroups (supporting domain evidence only): {len(review_rows)}
- Accepted member proteins: {len(selected_members)}
- Protein sequences recovered: {len(sequences)}
- Missing protein sequences: {len(missing_sequence_rows)}
- Unique annotated pathway accessions: {len(pathway_catalog_rows)}
- Pathway accessions without a resolved name: {unresolved}

## Evidence grades

- `A_multi_source`: both GO and named-pathway evidence.
- `B_core_plus_support`: core GO or named-pathway evidence plus supporting domain evidence.
- `C_single_core_source`: a single core evidence source; retain but discuss cautiously.
- `REVIEW_supporting_only`: domain/text support only; excluded from the main candidate table.

## Interpretation

These are literature-supported, annotation-based candidates, not experimentally
confirmed symbiosis genes. InterProScan pathway mappings are transferred from
reference databases and do not demonstrate that a complete pathway operates in
a cnidarian. Orthogroup presence remains confounded with host lineage in this
comparative design. Use `filtering_audit.tsv` to trace every inclusion.
"""
    (out / "README.md").write_text(report, encoding="utf-8")

    print(f"Examined orthogroups: {len(query_rows)}")
    print(f"Accepted orthogroups: {len(accepted_rows)}")
    print(f"Review-only orthogroups: {len(review_rows)}")
    print(f"Accepted member proteins: {len(selected_members)}")
    if not args.skip_fasta:
        print(f"FASTA sequences recovered: {len(sequences)}")
        print(f"Missing sequences: {len(missing_sequence_rows)}")
    print(f"Unresolved pathway accessions: {unresolved}/{len(pathway_catalog_rows)}")
    print(f"Output: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
