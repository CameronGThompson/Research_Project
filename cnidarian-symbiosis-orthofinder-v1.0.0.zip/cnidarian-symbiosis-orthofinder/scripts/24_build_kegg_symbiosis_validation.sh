#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
RESOURCE_DIR="${PROJECT_ROOT}/resources/kegg_symbiosis_validation"
OUTPUT_DIR="${PROJECT_ROOT}/results/symbiosis_pathway_candidates/kegg_validation"
CHECKPOINT="${PROJECT_ROOT}/.checkpoints/24_build_kegg_symbiosis_validation.done"

if [[ "${FORCE:-0}" != "1" && -s "${CHECKPOINT}" && \
      -s "${OUTPUT_DIR}/stage23_kegg_validation.tsv" && \
      -s "${OUTPUT_DIR}/run_summary.tsv" ]]; then
    echo "Stage 24 already complete. Set FORCE=1 to rebuild."
    exit 0
fi

mkdir -p "${RESOURCE_DIR}" "${OUTPUT_DIR}" "$(dirname "${CHECKPOINT}")"

download_reference() {
    local endpoint="$1"
    local destination="$2"
    local temporary="${destination}.part"

    [[ -s "${destination}" ]] && return 0

    if command -v curl >/dev/null 2>&1; then
        curl --fail --location --retry 3 \
            "https://rest.kegg.jp/${endpoint}" \
            --output "${temporary}"
    elif command -v wget >/dev/null 2>&1; then
        wget --tries=3 \
            "https://rest.kegg.jp/${endpoint}" \
            -O "${temporary}"
    else
        echo "ERROR: curl or wget is required" >&2
        return 1
    fi

    [[ -s "${temporary}" ]] || {
        echo "ERROR: KEGG returned an empty file for ${endpoint}" >&2
        return 1
    }
    mv "${temporary}" "${destination}"

    # KEGG asks clients to avoid rapid repeated requests.
    sleep 1
}

download_reference "list/pathway" "${RESOURCE_DIR}/kegg_pathway_list.tsv"
download_reference "link/pathway/ko" "${RESOURCE_DIR}/kegg_ko_to_pathway.tsv"
download_reference "list/module" "${RESOURCE_DIR}/kegg_module_list.tsv"
download_reference "link/module/ko" "${RESOURCE_DIR}/kegg_ko_to_module.tsv"

stage23_fasta="${PROJECT_ROOT}/results/symbiosis_pathway_candidates/candidate_proteins.faa"
blastkoala_fasta="${PROJECT_ROOT}/results/annotation/blastkoala_queries.faa"

command=(
    python3 "${PROJECT_ROOT}/scripts/build_kegg_symbiosis_validation.py"
    --blastkoala-complete "${PROJECT_ROOT}/results/annotation/blastkoala_candidate_ko.complete.tsv"
    --stage23-accepted "${PROJECT_ROOT}/results/symbiosis_pathway_candidates/candidate_orthogroups.tsv"
    --membership "${PROJECT_ROOT}/results/candidates/candidate_membership.long.tsv"
    --rules "${PROJECT_ROOT}/config/symbiosis_process_rules.tsv"
    --kegg-pathway-list "${RESOURCE_DIR}/kegg_pathway_list.tsv"
    --kegg-pathway-links "${RESOURCE_DIR}/kegg_ko_to_pathway.tsv"
    --kegg-module-list "${RESOURCE_DIR}/kegg_module_list.tsv"
    --kegg-module-links "${RESOURCE_DIR}/kegg_ko_to_module.tsv"
    --output-dir "${OUTPUT_DIR}"
)

if [[ -s "${stage23_fasta}" ]]; then
    command+=(--stage23-fasta "${stage23_fasta}")
else
    echo "WARNING: Stage 23 FASTA absent; corroborated FASTA will be empty." >&2
fi

if [[ -s "${blastkoala_fasta}" ]]; then
    command+=(--blastkoala-fasta "${blastkoala_fasta}")
else
    echo "WARNING: BlastKOALA query FASTA absent; KEGG-review FASTA will be empty." >&2
fi

"${command[@]}"
date -Iseconds > "${CHECKPOINT}"

