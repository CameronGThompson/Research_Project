#!/usr/bin/env python3
"""Create report-ready candidate tables and full-member amino-acid FASTA files.

The shortlist is an explicit manual curation layered on top of Stages 23 and
24.  This script preserves the original automated evidence and makes every
manual tier assignment and caveat visible in the output.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import os
import re
from collections import Counter, defaultdict
from pathlib import Path


def read_tsv(path: Path):
    """Read a TSV while tolerating comments and blank lines before its header."""
    with path.open(encoding="utf-8", errors="replace", newline="") as handle:
        lines = (line for line in handle if line.strip() and not line.startswith("#"))
        yield from csv.DictReader(lines, delimiter="\t")


def write_tsv(path: Path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            delimiter="\t",
            fieldnames=fieldnames,
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def require_file(path: Path, label: str):
    if not path.is_file():
        raise SystemExit(f"ERROR: {label} not found: {path}")


def unique_join(values):
    return ";".join(sorted({str(value) for value in values if str(value)}))


def split_semicolon(value):
    return [item for item in (value or "").split(";") if item]


def query_parts(query_id):
    parts = (query_id or "").split("|")
    return (
        parts[0] if parts else "",
        parts[1] if len(parts) > 1 else "",
        "|".join(parts[2:]) if len(parts) > 2 else "",
    )


def locate_proteome(project_root: Path, configured: str, extra_dirs):
    configured_path = Path(configured)
    if configured_path.is_file():
        return configured_path

    candidates = []
    if configured:
        candidates.append(project_root / configured)
        candidates.append(project_root / Path(configured).name)

    roots = [Path(value) for value in extra_dirs]
    roots += [
        project_root / "proteomes",
        project_root / "input" / "proteomes",
        project_root / "inputs" / "proteomes",
        project_root / "data" / "proteomes",
        project_root / "results" / "proteome_qc",
        project_root / "results" / "qc",
    ]
    filename = Path(configured).name
    for root in roots:
        candidates.extend([root / configured, root / filename])
    for candidate in candidates:
        if candidate.is_file():
            return candidate

    if not filename:
        return None
    skip = {".git", ".checkpoints", "logs", "software", "interproscan"}
    for current, dirs, files in os.walk(project_root):
        dirs[:] = [name for name in dirs if name not in skip]
        if filename in files:
            return Path(current) / filename
    return None


def fasta_aliases(header: str):
    token = header.split()[0]
    aliases = {token}
    aliases.update(part for part in token.split("|") if part)
    aliases.update(re.sub(r"\.\d+$", "", value) for value in list(aliases))
    return aliases


def extract_fasta(path: Path, wanted):
    found = {}
    wanted_by_alias = defaultdict(set)
    for wanted_id in wanted:
        wanted_by_alias[wanted_id].add(wanted_id)
        wanted_by_alias[re.sub(r"\.\d+$", "", wanted_id)].add(wanted_id)

    def save_record(header, parts):
        if header is None:
            return
        matched = set()
        for alias in fasta_aliases(header):
            matched.update(wanted_by_alias.get(alias, ()))
        if matched:
            sequence = "".join(parts).upper()
            for wanted_id in matched:
                found[wanted_id] = sequence

    opener = (
        lambda: gzip.open(path, mode="rt", encoding="utf-8", errors="replace")
        if path.suffix == ".gz"
        else path.open(encoding="utf-8", errors="replace")
    )
    header = None
    parts = []
    with opener() as handle:
        for raw in handle:
            line = raw.strip()
            if line.startswith(">"):
                save_record(header, parts)
                header = line[1:].strip()
                parts = []
            elif header is not None:
                parts.append(line)
    save_record(header, parts)
    return found


def wrap_fasta(sequence, width=80):
    return "\n".join(
        sequence[start : start + width]
        for start in range(0, len(sequence), width)
    )


def first_column(fieldnames, candidates, required=True):
    lookup = {name.lower(): name for name in fieldnames if name}
    for candidate in candidates:
        if candidate.lower() in lookup:
            return lookup[candidate.lower()]
    if required:
        raise SystemExit(
            "ERROR: none of these columns was found: " + ", ".join(candidates)
        )
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path("."))
    parser.add_argument("--curation", type=Path)
    parser.add_argument("--candidate-orthogroups", type=Path)
    parser.add_argument("--candidate-membership", type=Path)
    parser.add_argument("--species", type=Path)
    parser.add_argument("--query-summary", type=Path)
    parser.add_argument("--interpro-assignments", type=Path)
    parser.add_argument("--blastkoala-complete", type=Path)
    parser.add_argument("--kegg-stage23-validation", type=Path)
    parser.add_argument("--kegg-review", type=Path)
    parser.add_argument("--literature-sources", type=Path)
    parser.add_argument("--proteome-dir", action="append", default=[])
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--allow-missing-sequences", action="store_true")
    args = parser.parse_args()

    root = args.project_root.resolve()
    stage23 = root / "results" / "symbiosis_pathway_candidates"
    kegg = stage23 / "kegg_validation"
    interpro = root / "results" / "interproscan" / "candidates" / "summary"
    args.curation = args.curation or root / "config" / "final_report_candidate_curation.tsv"
    args.candidate_orthogroups = args.candidate_orthogroups or stage23 / "candidate_orthogroups.tsv"
    args.candidate_membership = args.candidate_membership or root / "results" / "candidates" / "candidate_membership.long.tsv"
    args.species = args.species or root / "config" / "species.tsv"
    args.query_summary = args.query_summary or interpro / "query_summary.tsv"
    args.interpro_assignments = args.interpro_assignments or interpro / "interpro_assignments.tsv"
    args.blastkoala_complete = args.blastkoala_complete or root / "results" / "annotation" / "blastkoala_candidate_ko.complete.tsv"
    args.kegg_stage23_validation = args.kegg_stage23_validation or kegg / "stage23_kegg_validation.tsv"
    args.kegg_review = args.kegg_review or kegg / "kegg_only_review_candidates.tsv"
    args.literature_sources = args.literature_sources or stage23 / "literature_sources.tsv"
    args.output_dir = args.output_dir or stage23 / "final_report"

    required = [
        (args.curation, "curation manifest"),
        (args.candidate_orthogroups, "Stage 23 candidate table"),
        (args.candidate_membership, "candidate membership table"),
        (args.species, "species table"),
        (args.query_summary, "InterProScan query summary"),
        (args.interpro_assignments, "InterPro assignment table"),
        (args.blastkoala_complete, "BlastKOALA complete table"),
        (args.kegg_stage23_validation, "Stage 24 accepted-candidate validation"),
        (args.kegg_review, "Stage 24 KEGG review table"),
        (args.literature_sources, "literature source table"),
    ]
    for path, label in required:
        require_file(path, label)

    curation = list(read_tsv(args.curation))
    if not curation:
        raise SystemExit("ERROR: curation manifest contains no rows")
    orthogroups = [row.get("orthogroup", "") for row in curation]
    duplicates = [item for item, count in Counter(orthogroups).items() if count > 1]
    if "" in orthogroups or duplicates:
        raise SystemExit(
            "ERROR: blank or duplicate curated orthogroups: " + ", ".join(duplicates)
        )
    for row in curation:
        if row.get("report_tier") not in {"PRIMARY", "SECONDARY"}:
            raise SystemExit(
                f"ERROR: invalid report_tier for {row['orthogroup']}: "
                f"{row.get('report_tier', '')}"
            )
        try:
            row["curation_order_int"] = int(row["curation_order"])
        except ValueError as error:
            raise SystemExit(
                f"ERROR: invalid curation_order for {row['orthogroup']}"
            ) from error
    curation.sort(key=lambda row: row["curation_order_int"])
    curated = {row["orthogroup"]: row for row in curation}

    stage23_rows = {row["orthogroup"]: row for row in read_tsv(args.candidate_orthogroups)}
    kegg_rows = {row["orthogroup"]: row for row in read_tsv(args.kegg_stage23_validation)}
    kegg_rows.update({row["orthogroup"]: row for row in read_tsv(args.kegg_review)})
    query_rows = list(read_tsv(args.query_summary))
    query_by_og = {row.get("orthogroup", "") or query_parts(row.get("query_id", ""))[0]: row for row in query_rows}
    blastkoala_by_og = {row.get("orthogroup", "") or query_parts(row.get("query_id", ""))[0]: row for row in read_tsv(args.blastkoala_complete)}

    interpro_by_query = defaultdict(list)
    for row in read_tsv(args.interpro_assignments):
        query_id = row.get("query_id", "")
        accession = row.get("interpro_accession", "")
        description = row.get("interpro_description", "")
        if query_id and accession:
            interpro_by_query[query_id].append(
                f"{accession}|{description}" if description else accession
            )

    membership_rows = list(read_tsv(args.candidate_membership))
    if not membership_rows:
        raise SystemExit("ERROR: candidate membership table contains no rows")
    membership_fields = list(membership_rows[0])
    og_col = first_column(membership_fields, ["orthogroup", "orthogroup_id"])
    of_col = first_column(membership_fields, ["orthofinder_name", "proteome", "proteome_name"])
    species_col = first_column(membership_fields, ["species", "species_name"], required=False)
    members_col = first_column(membership_fields, ["member_ids", "protein_ids", "members"], required=False)
    member_col = first_column(membership_fields, ["protein_id", "member_id", "original_protein_id"], required=False)
    count_col = first_column(membership_fields, ["copy_count", "member_count", "protein_count"], required=False)
    if members_col is None and member_col is None:
        raise SystemExit("ERROR: membership table has no member ID column")

    members_by_og = defaultdict(list)
    species_counts_by_og = defaultdict(lambda: defaultdict(int))
    membership_count_errors = []
    for row in membership_rows:
        orthogroup = row.get(og_col, "")
        if orthogroup not in curated:
            continue
        if members_col:
            proteins = [item.strip() for item in row.get(members_col, "").split(",") if item.strip()]
        else:
            protein = row.get(member_col, "").strip()
            proteins = [protein] if protein else []
        if count_col:
            declared = int(row.get(count_col, "0") or 0)
            if declared != len(proteins):
                membership_count_errors.append(
                    f"{orthogroup}/{row.get(of_col, '')}: declared {declared}, found {len(proteins)} IDs"
                )
        species_name = row.get(species_col, "") if species_col else row.get(of_col, "")
        for protein in proteins:
            members_by_og[orthogroup].append(
                {
                    "orthogroup": orthogroup,
                    "orthofinder_name": row.get(of_col, ""),
                    "species": species_name,
                    "protein_id": protein,
                }
            )
            species_counts_by_og[orthogroup][species_name] += 1
    if membership_count_errors:
        raise SystemExit("ERROR: membership count mismatch:\n" + "\n".join(membership_count_errors[:20]))
    absent = sorted(set(curated) - set(members_by_og))
    if absent:
        raise SystemExit("ERROR: curated orthogroups absent from membership: " + ", ".join(absent))

    species_rows = list(read_tsv(args.species))
    species_fields = list(species_rows[0]) if species_rows else []
    species_of_col = first_column(species_fields, ["orthofinder_name", "proteome", "proteome_name"])
    proteome_col = first_column(species_fields, ["proteome_file", "fasta", "proteome_path"])
    species_config = {row[species_of_col]: row for row in species_rows if row.get(species_of_col)}

    sequences = {}
    proteome_paths = {}
    missing_config = []
    wanted_by_of = defaultdict(set)
    for values in members_by_og.values():
        for item in values:
            wanted_by_of[item["orthofinder_name"]].add(item["protein_id"])
    for orthofinder_name, wanted in sorted(wanted_by_of.items()):
        config = species_config.get(orthofinder_name)
        if not config:
            missing_config.append(f"{orthofinder_name}: species configuration absent")
            continue
        proteome = locate_proteome(root, config.get(proteome_col, ""), args.proteome_dir)
        if proteome is None:
            missing_config.append(
                f"{orthofinder_name}: proteome not found ({config.get(proteome_col, '')})"
            )
            continue
        proteome_paths[orthofinder_name] = str(proteome)
        for protein_id, sequence in extract_fasta(proteome, wanted).items():
            sequences[(orthofinder_name, protein_id)] = sequence
    if missing_config:
        raise SystemExit("ERROR: proteome configuration problems:\n" + "\n".join(missing_config))

    literature_rows = {row.get("literature_key", ""): row for row in read_tsv(args.literature_sources)}
    used_literature = []
    for key in sorted({key for row in curation for key in split_semicolon(row.get("literature_keys", ""))}):
        if key in literature_rows:
            used_literature.append(literature_rows[key])
        else:
            used_literature.append(
                {"literature_key": key, "citation": "NOT_PRESENT_IN_STAGE23_SOURCE_TABLE", "url": ""}
            )

    report_rows = []
    member_output_rows = []
    matrix_rows = []
    for item in curation:
        orthogroup = item["orthogroup"]
        stage = stage23_rows.get(orthogroup, {})
        kegg_item = kegg_rows.get(orthogroup, {})
        query = query_by_og.get(orthogroup, {})
        blast = blastkoala_by_og.get(orthogroup, {})
        representative_query = query.get("query_id", "") or blast.get("query_id", "")
        species_counts = species_counts_by_og[orthogroup]
        members = members_by_og[orthogroup]
        report_rows.append(
            {
                **item,
                "manual_curation": 1,
                "stage23_selection_status": stage.get("selection_status", "NOT_ACCEPTED"),
                "stage23_evidence_grade": stage.get("evidence_grade", ""),
                "stage23_themes": stage.get("symbiosis_themes", ""),
                "stage23_evidence_sources": stage.get("evidence_sources", ""),
                "kegg_validation_label": kegg_item.get("kegg_validation_label", ""),
                "ko_assignments": kegg_item.get("ko_assignments", "") or blast.get("KO", ""),
                "relevant_kegg_records": kegg_item.get("relevant_kegg_records", ""),
                "kegg_themes": kegg_item.get("kegg_themes", ""),
                "member_species_count": len(species_counts),
                "member_species": unique_join(species_counts),
                "member_protein_count": len(members),
                "representative_query_id": representative_query,
                "matched_go_terms": stage.get("matched_go_terms", ""),
                "matched_interpro_entries": stage.get("matched_interpro_entries", ""),
                "representative_go_terms_all": query.get("go_terms", ""),
                "representative_interpro_entries_all": unique_join(interpro_by_query.get(representative_query, [])),
                "representative_signatures_all": query.get("signatures", ""),
            }
        )
        for member in members:
            member_output_rows.append(
                {
                    "curation_order": item["curation_order"],
                    "report_tier": item["report_tier"],
                    **member,
                    "sequence_recovered": int(
                        (member["orthofinder_name"], member["protein_id"]) in sequences
                    ),
                    "proteome_path": proteome_paths.get(member["orthofinder_name"], ""),
                }
            )
        for species_name, count in sorted(species_counts.items()):
            matrix_rows.append(
                {
                    "curation_order": item["curation_order"],
                    "orthogroup": orthogroup,
                    "report_tier": item["report_tier"],
                    "species": species_name,
                    "protein_count": count,
                }
            )

    report_fields = [
        "curation_order", "orthogroup", "report_tier", "functional_label",
        "primary_symbiosis_process", "curated_rationale", "interpretive_caveat",
        "manual_curation", "stage23_selection_status", "stage23_evidence_grade",
        "stage23_themes", "stage23_evidence_sources", "kegg_validation_label",
        "ko_assignments", "relevant_kegg_records", "kegg_themes",
        "member_species_count", "member_species", "member_protein_count",
        "representative_query_id", "matched_go_terms", "matched_interpro_entries",
        "representative_go_terms_all", "representative_interpro_entries_all",
        "representative_signatures_all", "literature_keys",
    ]
    member_fields = [
        "curation_order", "report_tier", "orthogroup", "orthofinder_name",
        "species", "protein_id", "sequence_recovered", "proteome_path",
    ]
    matrix_fields = [
        "curation_order", "orthogroup", "report_tier", "species", "protein_count"
    ]
    write_tsv(args.output_dir / "final_candidate_orthogroups.tsv", report_fields, report_rows)
    write_tsv(args.output_dir / "final_candidate_protein_members.tsv", member_fields, member_output_rows)
    write_tsv(args.output_dir / "final_candidate_species_matrix.long.tsv", matrix_fields, matrix_rows)
    write_tsv(
        args.output_dir / "literature_sources.tsv",
        ["literature_key", "citation", "url"],
        used_literature,
    )

    missing = [row for row in member_output_rows if not row["sequence_recovered"]]
    write_tsv(
        args.output_dir / "missing_sequences.tsv",
        ["orthogroup", "orthofinder_name", "species", "protein_id"],
        missing,
    )

    fasta_paths = {
        "ALL": args.output_dir / "final_candidate_proteins.faa",
        "PRIMARY": args.output_dir / "primary_candidate_proteins.faa",
        "SECONDARY": args.output_dir / "secondary_candidate_proteins.faa",
    }
    fasta_handles = {key: path.open("w", encoding="utf-8") for key, path in fasta_paths.items()}
    fasta_counts = Counter()
    try:
        for row in member_output_rows:
            sequence = sequences.get((row["orthofinder_name"], row["protein_id"]))
            if not sequence:
                continue
            header = (
                f'{row["orthogroup"]}|{row["orthofinder_name"]}|{row["protein_id"]} '
                f'species={row["species"]} tier={row["report_tier"]}'
            )
            record = f">{header}\n{wrap_fasta(sequence)}\n"
            fasta_handles["ALL"].write(record)
            fasta_handles[row["report_tier"]].write(record)
            fasta_counts["ALL"] += 1
            fasta_counts[row["report_tier"]] += 1
    finally:
        for handle in fasta_handles.values():
            handle.close()

    summary_rows = [
        {"metric": "curated_orthogroups", "value": len(curation)},
        {"metric": "primary_orthogroups", "value": sum(row["report_tier"] == "PRIMARY" for row in curation)},
        {"metric": "secondary_orthogroups", "value": sum(row["report_tier"] == "SECONDARY" for row in curation)},
        {"metric": "member_species_occurrences", "value": len(matrix_rows)},
        {"metric": "member_proteins", "value": len(member_output_rows)},
        {"metric": "fasta_records_all", "value": fasta_counts["ALL"]},
        {"metric": "fasta_records_primary", "value": fasta_counts["PRIMARY"]},
        {"metric": "fasta_records_secondary", "value": fasta_counts["SECONDARY"]},
        {"metric": "missing_sequences", "value": len(missing)},
    ]
    write_tsv(args.output_dir / "run_summary.tsv", ["metric", "value"], summary_rows)

    readme = """# Final report candidate shortlist

This directory is a manually curated reporting layer over the automated Stage
23 literature screen and Stage 24 KEGG cross-check. `final_candidate_orthogroups.tsv`
is the main report table. Every manual promotion, rationale and limitation is
explicit. PRIMARY and SECONDARY are reporting priorities, not statistical
confidence intervals and not evidence of experimental validation.

The FASTA files contain every orthogroup member recovered from the configured
target-species proteomes. `missing_sequences.tsv` must be empty for a complete
run. The KEGG-only families remain annotation-based review candidates.

OG0015642 is intentionally absent: it should be reported separately as the
novel secreted coral orthogroup that contributed to an enriched toxin-associated
category, rather than as a literature-pathway candidate.
"""
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "README.md").write_text(readme, encoding="utf-8")

    print(f"Curated orthogroups: {len(curation)}")
    print(f"Member proteins: {len(member_output_rows)}")
    print(f"FASTA records recovered: {fasta_counts['ALL']}")
    print(f"Missing sequences: {len(missing)}")
    print(f"Output: {args.output_dir.resolve()}")
    if missing and not args.allow_missing_sequences:
        raise SystemExit(
            "ERROR: one or more curated member sequences were not recovered; "
            "inspect missing_sequences.tsv"
        )


if __name__ == "__main__":
    raise SystemExit(main())
