#!/usr/bin/env python3
"""Build a joined TSV for the 12 literature/KEGG-prioritised candidates."""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

from openpyxl import load_workbook


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workbook",
        type=Path,
        default=root / "data/final_candidates/Pathway_Candidate_Final_Tables.xlsx",
    )
    parser.add_argument(
        "--curation",
        type=Path,
        default=root / "config/final_report_candidate_curation.tsv",
    )
    parser.add_argument(
        "--evidence",
        type=Path,
        default=root / "data/final_candidates/Figure_5_candidate_evidence_data.tsv",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "data/final_candidates/final_candidate_summary.tsv",
    )
    return parser.parse_args()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def strip_role_citation(value: str) -> str:
    return re.sub(
        r"\s*\([^()]*\b(?:19|20)\d{2}\b[^()]*\)\s*$", "", value
    ).strip()


def clean_report_text(value: str) -> str:
    return (
        value.replace("NF-kappaB", "NF-κB")
        .replace("TGF-beta", "TGF-β")
        .replace("GO KEGG;", "GO + KEGG;")
    )


def workbook_rows(path: Path) -> dict[str, dict[str, str]]:
    workbook = load_workbook(path, data_only=True, read_only=True)
    result: dict[str, dict[str, str]] = {}
    for sheet in workbook.worksheets:
        rows = sheet.iter_rows(values_only=True)
        header = [str(value) for value in next(rows)]
        for values in rows:
            row = {
                key: "" if value is None else str(value)
                for key, value in zip(header, values)
            }
            row = {key: clean_report_text(value) for key, value in row.items()}
            row["Proposed Symbiosis Role"] = strip_role_citation(row["Proposed Symbiosis Role"])
            result[row["Orthogroup"]] = row
    return result


def main() -> int:
    args = parse_args()
    curation = read_tsv(args.curation)
    evidence = {row["orthogroup"]: row for row in read_tsv(args.evidence)}
    report_rows = workbook_rows(args.workbook)

    ids = {row["orthogroup"] for row in curation}
    if ids != set(evidence) or ids != set(report_rows):
        raise ValueError("Workbook, curation manifest and evidence matrix disagree")

    fields = [
        "curation_order",
        "orthogroup",
        "report_tier",
        "predicted_function",
        "proposed_symbiosis_role",
        "species",
        "report_evidence",
        "evidence_class",
        "go_support",
        "interpro_support",
        "ko_support",
        "kegg_support",
        "literature_support",
        "literature_keys",
        "curated_rationale",
        "interpretive_caveat",
    ]
    output_rows = []
    for curated in sorted(curation, key=lambda row: int(row["curation_order"])):
        orthogroup = curated["orthogroup"]
        matrix = evidence[orthogroup]
        report = report_rows[orthogroup]
        output_rows.append(
            {
                "curation_order": curated["curation_order"],
                "orthogroup": orthogroup,
                "report_tier": curated["report_tier"],
                "predicted_function": report["Predicted Function"],
                "proposed_symbiosis_role": report["Proposed Symbiosis Role"],
                "species": report["Species"],
                "report_evidence": report["Evidence"],
                "evidence_class": matrix["evidence_class"],
                "go_support": matrix["go"],
                "interpro_support": matrix["interpro"],
                "ko_support": matrix["ko"],
                "kegg_support": matrix["kegg"],
                "literature_support": matrix["literature"],
                "literature_keys": curated["literature_keys"],
                "curated_rationale": clean_report_text(curated["curated_rationale"]),
                "interpretive_caveat": clean_report_text(curated["interpretive_caveat"]),
            }
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=fields, delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(output_rows)

    primary = sum(row["report_tier"] == "PRIMARY" for row in output_rows)
    secondary = sum(row["report_tier"] == "SECONDARY" for row in output_rows)
    if (primary, secondary) != (4, 8):
        raise ValueError(f"Expected 4 primary and 8 secondary candidates, got {primary}/{secondary}")
    print(f"Wrote {len(output_rows)} candidates to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
