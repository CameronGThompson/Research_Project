#!/usr/bin/env python3
"""Render the candidate tables in an Excel workbook as publication-ready images."""

from __future__ import annotations

import argparse
import re
import textwrap
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from openpyxl import load_workbook


COLUMN_WIDTHS = [0.11, 0.23, 0.31, 0.22, 0.13]
WRAP_WIDTHS = [15, 34, 48, 34, 25]

COLORS = {
    "header": "#17365D",
    "primary_section": "#2E6F95",
    "primary_odd": "#E5F0F7",
    "primary_even": "#F2F7FB",
    "secondary_section": "#B66A2C",
    "secondary_odd": "#FCE9D5",
    "secondary_even": "#FFF4E8",
    "grid": "#C7D0D9",
    "text": "#17212B",
    "white": "#FFFFFF",
}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workbook", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser.parse_args()


def clean_text(value) -> str:
    text = "" if value is None else str(value)
    return (
        text.replace("NF-kappaB", "NF-κB")
        .replace("TGF-beta", "TGF-β")
        .replace("GO KEGG;", "GO + KEGG;")
    )


def read_sheet(ws):
    rows = [[clean_text(value) for value in row] for row in ws.iter_rows(values_only=True)]
    if not rows:
        raise ValueError(f"Worksheet {ws.title!r} is empty")
    if len(rows[0]) != 5:
        raise ValueError(f"Worksheet {ws.title!r} must contain five columns")
    return rows[0], rows[1:]


def wrap_cell(text: str, width: int) -> str:
    parts = []
    for paragraph in text.splitlines() or [""]:
        parts.extend(textwrap.wrap(
            paragraph, width=width, break_long_words=False,
            break_on_hyphens=False,
        ) or [""])
    return "\n".join(parts)


def remove_trailing_citation(role: str) -> str:
    """Remove a final parenthetical author-year citation from a role description."""
    return re.sub(r"\s*\([^()]*\b(?:19|20)\d{2}\b[^()]*\)\s*$", "", role).strip()


def without_role_citations(rows):
    cleaned = []
    for row in rows:
        updated = list(row)
        updated[2] = remove_trailing_citation(updated[2])
        cleaned.append(updated)
    return cleaned


def render_table(headers, sections, output_prefix: Path, title: str, subtitle: str, footnote: str):
    mpl.rcParams.update({
        "font.family": "DejaVu Sans",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })

    prepared = []
    units = 1.55  # main header
    for tier, rows in sections:
        prepared.append(("section", tier, None, 1.15))
        units += 1.15
        for row in rows:
            wrapped = [wrap_cell(text, width) for text, width in zip(row, WRAP_WIDTHS)]
            lines = max(cell.count("\n") + 1 for cell in wrapped)
            row_units = max(1.75, 0.72 * lines + 0.42)
            prepared.append(("data", tier, wrapped, row_units))
            units += row_units

    figure_height = max(6.5, 0.58 * units + 2.2)
    fig, ax = plt.subplots(figsize=(18, figure_height))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    fig.text(0.5, 0.965, title, ha="center", va="top", fontsize=17, fontweight="bold", color=COLORS["text"])
    fig.text(0.5, 0.925, subtitle, ha="center", va="top", fontsize=10.5, color="#4A5560")

    left, right = 0.025, 0.975
    top, bottom = 0.865, 0.055
    table_width = right - left
    available_height = top - bottom
    unit_height = available_height / units

    x_edges = [left]
    for width in COLUMN_WIDTHS:
        x_edges.append(x_edges[-1] + table_width * width)

    # Column header.
    header_height = 1.55 * unit_height
    y = top
    for col, header in enumerate(headers):
        x0, x1 = x_edges[col], x_edges[col + 1]
        ax.add_patch(Rectangle((x0, y - header_height), x1 - x0, header_height,
                               facecolor=COLORS["header"], edgecolor=COLORS["white"], linewidth=1.1))
        ax.text((x0 + x1) / 2, y - header_height / 2, wrap_cell(header, WRAP_WIDTHS[col]),
                ha="center", va="center", color="white", fontsize=10.3, fontweight="bold")
    y -= header_height

    row_number = {"PRIMARY": 0, "SECONDARY": 0}
    for row_type, tier, cells, row_units in prepared:
        height = row_units * unit_height
        if row_type == "section":
            fill = COLORS[f"{tier.lower()}_section"]
            ax.add_patch(Rectangle((left, y - height), table_width, height,
                                   facecolor=fill, edgecolor=COLORS["white"], linewidth=1.1))
            count = next(len(rows) for name, rows in sections if name == tier)
            ax.text(left + 0.012, y - height / 2, f"{tier} CANDIDATES  (n = {count})",
                    ha="left", va="center", color="white", fontsize=10.5, fontweight="bold")
        else:
            row_number[tier] += 1
            parity = "odd" if row_number[tier] % 2 else "even"
            fill = COLORS[f"{tier.lower()}_{parity}"]
            for col, cell_text in enumerate(cells):
                x0, x1 = x_edges[col], x_edges[col + 1]
                ax.add_patch(Rectangle((x0, y - height), x1 - x0, height,
                                       facecolor=fill, edgecolor=COLORS["grid"], linewidth=0.85))
                fontweight = "bold" if col in {0, 4} else "normal"
                fontstyle = "italic" if col == 3 else "normal"
                fontsize = 9.5 if col != 4 else 9.2
                ax.text(x0 + 0.008, y - height / 2, cell_text,
                        ha="left", va="center", color=COLORS["text"], fontsize=fontsize,
                        fontweight=fontweight, fontstyle=fontstyle, linespacing=1.25)
        y -= height

    fig.text(0.5, 0.025, footnote,
             ha="center", va="bottom", fontsize=9, color="#5A6570", fontstyle="italic")

    output_prefix.parent.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "pdf", "svg"):
        kwargs = {"dpi": 300} if extension == "png" else {}
        fig.savefig(output_prefix.with_suffix(f".{extension}"), bbox_inches="tight", **kwargs)
    plt.close(fig)


def main():
    args = parse_args()
    wb = load_workbook(args.workbook, data_only=True)
    primary_headers, primary_rows = read_sheet(wb[wb.sheetnames[0]])
    if "Secondary_Candidates" not in wb.sheetnames:
        raise ValueError("Workbook does not contain the Secondary_Candidates worksheet")
    secondary_headers, secondary_rows = read_sheet(wb["Secondary_Candidates"])
    if primary_headers != secondary_headers:
        raise ValueError("Primary and secondary worksheets have different headers")

    primary_rows_no_citations = without_role_citations(primary_rows)
    secondary_rows_no_citations = without_role_citations(secondary_rows)

    render_table(
        primary_headers,
        [("PRIMARY", primary_rows_no_citations), ("SECONDARY", secondary_rows_no_citations)],
        args.output_dir / "Table_1_final_candidates_no_role_citations",
        "Final symbiosis-associated candidate orthogroups",
        "Primary candidates are shown in blue and secondary candidates in amber",
        "Primary and secondary labels indicate reporting priority, not experimental validation.",
    )
    render_table(
        primary_headers,
        [("PRIMARY", primary_rows)],
        args.output_dir / "Primary_candidates_first_tab",
        "Primary symbiosis-associated candidate orthogroups",
        "Rendered from the first worksheet of Pathway_Candidate_Final_Tables.xlsx",
        "Primary indicates reporting priority, not experimental validation.",
    )
    print(f"Primary rows: {len(primary_rows)}")
    print(f"Secondary rows: {len(secondary_rows)}")
    print(f"Output directory: {args.output_dir}")


if __name__ == "__main__":
    main()
