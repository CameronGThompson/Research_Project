#!/usr/bin/env python3
"""Build Supplementary Table S2 from the candidate and HMM-validation TSVs."""

from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.table import Table, TableStyleInfo


CLASS_BY_GROUP = {
    "anemone": "Anthozoa",
    "coral": "Anthozoa",
    "jellyfish": "Scyphozoa",
    "hydra": "Hydrozoa",
}

GROUP_ORDER = {"coral": 0, "anemone": 1, "jellyfish": 2, "hydra": 3}
CLASS_ORDER = {"Anthozoa": 0, "Scyphozoa": 1, "Hydrozoa": 2}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-master", required=True, type=Path)
    parser.add_argument("--membership", required=True, type=Path)
    parser.add_argument("--absence-validation", required=True, type=Path)
    parser.add_argument("--hmm-hits", type=Path)
    parser.add_argument("--output-xlsx", required=True, type=Path)
    parser.add_argument("--output-tsv", required=True, type=Path)
    return parser.parse_args()


def read_tsv(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        yield from csv.DictReader(handle, delimiter="\t")


def pretty_species(name: str) -> str:
    return name.replace("_", " ")


def yes_no(value: str | int | bool) -> str:
    return "Yes" if str(value).strip() in {"1", "True", "true", "YES", "Yes"} else "No"


def build_records(args: argparse.Namespace):
    master_rows = list(read_tsv(args.candidate_master))
    master = {row["orthogroup"]: row for row in master_rows}
    if len(master) != len(master_rows):
        raise ValueError("candidate_master.tsv contains duplicate orthogroup identifiers")

    validation_rows = list(read_tsv(args.absence_validation))
    validation = {row["orthogroup"]: row for row in validation_rows}
    if len(validation) != len(validation_rows):
        raise ValueError("absence_validation.tsv contains duplicate orthogroup identifiers")

    membership = defaultdict(list)
    species_metadata = {}
    for row in read_tsv(args.membership):
        membership[row["orthogroup"]].append(row)
        species_metadata[row["orthofinder_name"]] = {
            "species": row["species"],
            "host_group": row["host_group"],
            "symbiotic": int(row["symbiotic"]),
        }

    missing_validation = set(master) - set(validation)
    extra_validation = set(validation) - set(master)
    if missing_validation or extra_validation:
        raise ValueError(
            f"Candidate/HMM ID mismatch: {len(missing_validation)} missing and "
            f"{len(extra_validation)} extra validation records"
        )
    if set(master) != set(membership):
        raise ValueError("Candidate and membership orthogroup identifiers do not match")
    if any(len(rows) != len(species_metadata) for rows in membership.values()):
        raise ValueError("Each candidate must have exactly one membership row per species")

    hit_species = defaultdict(set)
    if args.hmm_hits:
        for row in read_tsv(args.hmm_hits):
            orthogroup = row["orthogroup"]
            of_name = row["orthofinder_name"]
            if orthogroup in master and of_name in species_metadata:
                hit_species[orthogroup].add(species_metadata[of_name]["species"])

    sym_species = sorted(
        (m["species"] for m in species_metadata.values() if m["symbiotic"]),
        key=lambda s: s,
    )
    nonsym_species = sorted(
        (m["species"] for m in species_metadata.values() if not m["symbiotic"]),
        key=lambda s: s,
    )
    species_order = sym_species + nonsym_species

    group_sym_species = defaultdict(set)
    for meta in species_metadata.values():
        if meta["symbiotic"]:
            group_sym_species[meta["host_group"]].add(meta["species"])

    records = []
    copy_matrix = []
    for orthogroup in sorted(master):
        mrow = master[orthogroup]
        vrow = validation[orthogroup]
        rows = membership[orthogroup]

        copies = {row["species"]: int(row["copy_count"]) for row in rows}
        present_rows = [row for row in rows if int(row["symbiotic"]) and int(row["copy_count"]) > 0]
        present_species = sorted((row["species"] for row in present_rows), key=lambda s: s)
        groups = sorted({row["host_group"] for row in present_rows}, key=lambda g: GROUP_ORDER[g])
        classes = sorted({CLASS_BY_GROUP[group] for group in groups}, key=lambda c: CLASS_ORDER[c])
        core_groups = []
        for group in groups:
            group_present = {row["species"] for row in present_rows if row["host_group"] == group}
            if group_present == group_sym_species[group]:
                core_groups.append(group)

        replicated = yes_no(mrow["tier__symbiotic_only_replicated"])
        cross_lineage = yes_no(mrow["tier__symbiotic_only_cross_lineage"])
        broad = yes_no(mrow["tier__symbiotic_only_broad"])
        universal = yes_no(mrow["tier__symbiotic_only_universal"])

        if len(groups) == 1:
            category = f"{groups[0].capitalize()}-specific"
            category += "; replicated" if replicated == "Yes" else "; single-species"
        else:
            category = "Cross-lineage; replicated"
        if broad == "Yes":
            category += "; broad"
        if universal == "Yes":
            category += "; universal"

        tiers = ["Symbiotic-specific"]
        if replicated == "Yes":
            tiers.append("Replicated")
        if cross_lineage == "Yes":
            tiers.append("Cross-lineage")
        if broad == "Yes":
            tiers.append("Broad")
        if universal == "Yes":
            tiers.append("Universal")

        raw_status = vrow["absence_status"]
        if raw_status == "NO_HMM_HIT_AT_THRESHOLDS":
            display_status = "HMM-strict: retained"
        elif raw_status == "FLAG_HOMOLOG_DETECTED":
            display_status = "Reclassified: non-symbiotic homologue detected"
        else:
            display_status = raw_status

        hit_names = sorted(hit_species.get(orthogroup, set()))
        expected_hit_species = int(vrow["n_nonsymbiotic_species_hit"])
        if args.hmm_hits and len(hit_names) != expected_hit_species:
            raise ValueError(
                f"{orthogroup}: aggregated HMM-hit species ({len(hit_names)}) does not match "
                f"absence_validation.tsv ({expected_hit_species})"
            )

        present_with_counts = [f"{pretty_species(s)} ({copies[s]})" for s in present_species]
        record = {
            "Orthogroup": orthogroup,
            "Symbiotic species present": "; ".join(pretty_species(s) for s in present_species),
            "Species copy counts": "; ".join(present_with_counts),
            "Symbiotic species present (n)": int(mrow["n_symbiotic_present"]),
            "Host groups present": "; ".join(g.capitalize() for g in groups),
            "Host groups present (n)": int(mrow["n_symbiotic_groups_present"]),
            "Cnidarian classes present": "; ".join(classes),
            "Distribution category": category,
            "Candidate tiers": "; ".join(tiers),
            "Core host group(s)": "; ".join(g.capitalize() for g in core_groups) or "None",
            "Replicated": replicated,
            "Cross-lineage": cross_lineage,
            "Broad": broad,
            "Universal": universal,
            "HMM-validation status": display_status,
            "Passing HMM hits (n)": int(vrow["passing_hmm_hits"]),
            "Non-symbiotic species with HMM hits (n)": expected_hit_species,
            "Non-symbiotic species with HMM hits": "; ".join(pretty_species(s) for s in hit_names) or "None",
            "Total copies in symbiotic proteomes": sum(copies[s] for s in sym_species),
        }
        records.append(record)
        copy_matrix.append({"Orthogroup": orthogroup, **{pretty_species(s): copies[s] for s in species_order}})

    return records, copy_matrix, sym_species, nonsym_species


def write_tsv(path: Path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def apply_sheet_style(ws, header_row: int, widths: dict[str, float], table_name: str):
    navy = "17365D"
    white = "FFFFFF"
    thin_grey = Side(style="thin", color="D9E2F3")
    for cell in ws[header_row]:
        cell.fill = PatternFill("solid", fgColor=navy)
        cell.font = Font(color=white, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=thin_grey)
    ws.row_dimensions[header_row].height = 34
    for header, width in widths.items():
        for cell in ws[header_row]:
            if cell.value == header:
                ws.column_dimensions[cell.column_letter].width = width
                break
    ws.freeze_panes = f"A{header_row + 1}"
    ws.auto_filter.ref = f"A{header_row}:{ws.cell(ws.max_row, ws.max_column).coordinate}"
    table = Table(displayName=table_name, ref=ws.auto_filter.ref)
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2", showFirstColumn=False, showLastColumn=False,
        showRowStripes=True, showColumnStripes=False,
    )
    ws.add_table(table)
    ws.sheet_view.showGridLines = False


def write_workbook(path: Path, records, copy_matrix, sym_species, nonsym_species):
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Table S2"

    title = "Table S2. Species distribution, classification and HMM-based validation of candidate orthogroups"
    note = (
        "Each row represents one symbiotic-specific candidate orthogroup. Candidate tiers overlap. "
        "Species copy counts are shown in parentheses; HMM-strict candidates had no detectable "
        "homologue in any sampled non-symbiotic proteome at the applied thresholds."
    )
    ncols = len(records[0])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    ws["A1"] = title
    ws["A1"].font = Font(size=14, bold=True, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor="17365D")
    ws["A1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 25
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    ws["A2"] = note
    ws["A2"].font = Font(size=10, italic=True, color="404040")
    ws["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[2].height = 34

    headers = list(records[0])
    for col, header in enumerate(headers, 1):
        ws.cell(4, col, header)
    for row_idx, record in enumerate(records, 5):
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row_idx, col_idx, record[header])
            cell.alignment = Alignment(vertical="top", wrap_text=header in {
                "Symbiotic species present", "Species copy counts", "Host groups present",
                "Cnidarian classes present", "Distribution category", "Candidate tiers",
                "Core host group(s)", "HMM-validation status",
                "Non-symbiotic species with HMM hits",
            })

    widths = {
        "Orthogroup": 15,
        "Symbiotic species present": 48,
        "Species copy counts": 55,
        "Symbiotic species present (n)": 14,
        "Host groups present": 25,
        "Host groups present (n)": 13,
        "Cnidarian classes present": 24,
        "Distribution category": 31,
        "Candidate tiers": 35,
        "Core host group(s)": 22,
        "Replicated": 12,
        "Cross-lineage": 13,
        "Broad": 10,
        "Universal": 10,
        "HMM-validation status": 42,
        "Passing HMM hits (n)": 15,
        "Non-symbiotic species with HMM hits (n)": 18,
        "Non-symbiotic species with HMM hits": 52,
        "Total copies in symbiotic proteomes": 18,
    }
    apply_sheet_style(ws, 4, widths, "TableS2Candidates")
    ws.auto_filter.ref = f"A4:{ws.cell(ws.max_row, ws.max_column).coordinate}"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.print_title_rows = "1:4"

    # Highlight retained HMM-strict rows in pale green and reclassified rows in pale orange.
    hmm_col = headers.index("HMM-validation status") + 1
    hmm_letter = ws.cell(4, hmm_col).column_letter
    data_range = f"A5:{ws.cell(ws.max_row, ws.max_column).coordinate}"
    ws.conditional_formatting.add(
        data_range,
        FormulaRule(formula=[f'LEFT(${hmm_letter}5,10)="HMM-strict"'], fill=PatternFill("solid", fgColor="E2F0D9")),
    )
    ws.conditional_formatting.add(
        data_range,
        FormulaRule(formula=[f'LEFT(${hmm_letter}5,12)="Reclassified"'], fill=PatternFill("solid", fgColor="FCE4D6")),
    )

    # Exact species-by-orthogroup copy-count matrix.
    matrix = wb.create_sheet("Species copy counts")
    matrix_headers = list(copy_matrix[0])
    for col, header in enumerate(matrix_headers, 1):
        matrix.cell(1, col, header)
    for row_idx, record in enumerate(copy_matrix, 2):
        for col_idx, header in enumerate(matrix_headers, 1):
            matrix.cell(row_idx, col_idx, record[header])
    matrix_widths = {header: 20 for header in matrix_headers}
    matrix_widths["Orthogroup"] = 15
    apply_sheet_style(matrix, 1, matrix_widths, "SpeciesCopyCountMatrix")
    for col_idx, species in enumerate(sym_species, 2):
        cell = matrix.cell(1, col_idx)
        cell.fill = PatternFill("solid", fgColor="548235")
        cell.comment = Comment("Symbiotic proteome", "OpenAI")
    for col_idx, species in enumerate(nonsym_species, 2 + len(sym_species)):
        cell = matrix.cell(1, col_idx)
        cell.fill = PatternFill("solid", fgColor="7F7F7F")
        cell.comment = Comment("Non-symbiotic proteome", "OpenAI")
    matrix.sheet_properties.pageSetUpPr.fitToPage = True
    matrix.page_setup.orientation = "landscape"
    matrix.page_setup.fitToWidth = 1
    matrix.page_setup.fitToHeight = 0

    # Compact summary/check sheet.
    summary = wb.create_sheet("Summary and definitions")
    status_counts = Counter(row["HMM-validation status"] for row in records)
    tier_counts = {
        "All symbiotic-specific candidates": len(records),
        "Single-species candidates": sum(row["Replicated"] == "No" for row in records),
        "Replicated candidates": sum(row["Replicated"] == "Yes" for row in records),
        "Cross-lineage candidates": sum(row["Cross-lineage"] == "Yes" for row in records),
        "Broad candidates": sum(row["Broad"] == "Yes" for row in records),
        "Universal candidates": sum(row["Universal"] == "Yes" for row in records),
        "HMM-strict candidates retained": status_counts["HMM-strict: retained"],
        "Candidates reclassified after HMM search": status_counts[
            "Reclassified: non-symbiotic homologue detected"
        ],
    }
    summary.append(["Metric", "Count"])
    for label, count in tier_counts.items():
        summary.append([label, count])
    summary.column_dimensions["A"].width = 48
    summary.column_dimensions["B"].width = 14
    for cell in summary[1]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
    definitions = [
        ("Symbiotic-specific", "Present in at least one symbiotic proteome and absent from all sampled non-symbiotic proteomes in the initial OrthoFinder clustering."),
        ("Replicated", "Present in at least two symbiotic species."),
        ("Cross-lineage", "Present in symbiotic species from at least two host groups: coral, anemone, jellyfish or hydra."),
        ("Broad", "Present in at least four symbiotic species across at least two host groups."),
        ("Universal", "Present in all eight symbiotic species."),
        ("Core host group", "Present in every designated symbiotic species within the named host group."),
        ("HMM-strict: retained", "No non-symbiotic homologue was detected at the applied profile-HMM thresholds."),
        ("Reclassified", "At least one homologue was detected in a sampled non-symbiotic proteome by profile-HMM search."),
    ]
    start = len(tier_counts) + 4
    summary.cell(start, 1, "Term")
    summary.cell(start, 2, "Definition")
    for cell in summary[start]:
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.font = Font(color="FFFFFF", bold=True)
    for term, definition in definitions:
        summary.append([term, definition])
    summary.column_dimensions["B"].width = 105
    for row in summary.iter_rows(min_row=start + 1, max_row=summary.max_row):
        row[1].alignment = Alignment(wrap_text=True, vertical="top")
    summary.freeze_panes = "A2"
    summary.sheet_view.showGridLines = False

    # Workbook metadata.
    wb.properties.title = "Supplementary Table S2: candidate orthogroups"
    wb.properties.subject = "Species distribution, candidate category and HMM-validation status"
    wb.properties.creator = "Comparative cnidarian symbiosis analysis workflow"
    wb.save(path)


def main():
    args = parse_args()
    records, copy_matrix, sym_species, nonsym_species = build_records(args)
    if len(records) != 2864:
        raise ValueError(f"Expected 2,864 candidates, found {len(records):,}")
    write_tsv(args.output_tsv, records)
    write_workbook(args.output_xlsx, records, copy_matrix, sym_species, nonsym_species)
    print(f"Wrote {len(records):,} unique candidate orthogroups")
    print(f"Excel: {args.output_xlsx}")
    print(f"TSV:   {args.output_tsv}")


if __name__ == "__main__":
    main()
