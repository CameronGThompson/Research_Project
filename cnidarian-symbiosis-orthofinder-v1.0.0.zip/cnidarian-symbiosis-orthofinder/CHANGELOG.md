# Changelog

## 1.0.0

- Added compact OrthoFinder statistics, species tree and orthogroup-sharing data.
- Added candidate classification, membership and HMM absence-validation results.
- Added InterProScan coverage and complete functional-enrichment outputs.
- Added literature-guided Stage 23, KEGG-validation Stage 24 and final-curation
  Stage 25 scripts with SLURM templates.
- Added the 12-candidate evidence matrix, final report table and supplementary
  Tables S2–S3.
- Added reproducible report figures in PNG, PDF and SVG formats.
- Added package validation, data checksums and GitHub Actions validation.
- Corrected literature metadata for Barott et al. (2015) and clarified that
  Tame et al. (2023) concerns mussel–bacterial symbiosis.

